<?php

include_once('../header.php');

if(empty($_SESSION['user_id'])) {
  // header("Location: ../index.php");
  
}

?>

<html>
  <head>
    
  <title>Dashboard</title>

   <style>
    *
    {
       border-color:black;
       size: 25px;
    }
.al1{
     font-size: 30px;
     color:purple;
     text-decoration:none;     
    }
.ti{
  text-align:center;
    font-size:20px;
    margin-right: 12%;
    color: #fff;
   }
   .tx{
    font-size:25px;
    padding:0px;
    border-radius:7px ;
    border:2px solid #052d2d;
    width:50%;
   }
   #hd{
    top:0;
    position:fixed;
    width:100%;
   }
   </style>
  </head>
  <body>

  <nav id="hd" class="navbar navbar-expand-lg navbar-dark bg-dark shadow ">
    <div class="container-fluid">
     <a class="navbar-brand" href="../index.php">Mr.Patel's-JOB.com</a>
     <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
       <span class="navbar-toggler-icon"></span>
      </button>
      <div class="container">
        <h3 class="ti" >My Dashbord</h3>
      </div>
      <div class="tx" >
        <a class="btn btn-outline-info" href="../User/dashboard.php" style="text-decoration:none;  color:white">Dashbord</a>
        <a class="btn btn-outline-info" href="../User/profile.php" style="text-decoration:none;  color:white">Profile</a>
        <a class="btn btn-outline-info" href="editprofile.php" style="text-decoration:none;  color:white">Edit</a>
        <a class="btn btn-outline-info" href="applied-jobs.php" style="text-decoration:none;  color:white" >My Applied Jobs</a>
      </div>
      <a class="btn btn-danger me-2" href="../logout.php">Logout</a>
    </div>
  </nav>
  <br><br><br><br><br>

    <div class="container">

      <?php if(isset($_SESSION['jobApplySuccess'])) { ?> 
      <div>
                <p id="successMessage" style="text-align: center; color: red; font-size: 28px;">You have applied successfully!</p>
              </div>
      <?php unset($_SESSION['jobApplySuccess']); } ?>
  
<div class="mt-1">
  <div class="row" align="center">
    <h1>Active Jobs</h1><hr/>
            <table class="table table-bordered table-hover mb-0">
              <thead class="bg-dark text-white">
                <th>Com_Id</th>
                <th >Job Name</th>
                <th >Job Description</th>
                <th >Minimum Salary</th>
                <th >Maximum Salary</th>
                <th >Experience</th>
                <th >Qualification</th>
                <th >Action</th>
              </thead>
              <tbody>
                <?php 
                  $sql = "SELECT * FROM job_post";
                  $result = mysql_query($sql);
                  if(mysql_num_rows($result) > 0) {
                    while($row = mysql_fetch_assoc($result)) 
                    {
                      $sql1 = "SELECT * FROM apply_job_post WHERE user_id='$_SESSION[user_id]' AND jobpost_id='$row[jobpost_id]'";
                      $result1 = mysql_query($sql1);
                      
                     ?>
                      <tr>
                      <td ><?php echo $row['com_id']; ?></td>
                        <td ><?php echo $row['jobtitle']; ?></td>
                        <td ><?php echo $row['description']; ?></td>
                        <td >Rs.<?php echo $row['minimumsalary']; ?></td>
                        <td >Rs.<?php echo $row['maximumsalary']; ?></td>
                        <td ><?php echo $row['experience']; ?></td>
                        <td ><?php echo $row['qualification']; ?></td>
  
                        <?php
                        if(mysql_num_rows($result1) > 0) {
                          ?>
                            <td ><strong>Applied!</strong></td>
                          <?php
                        } else {
                       ?>
                       <td align="center" ><a class="btn btn-outline-success" href="apply-job-post.php?id=<?php echo $row['jobpost_id']; ?>">Apply</a></td>
                       <?php } ?>
                      </tr>
                     <?php
                    }
                  }
                  
                ?>
              </tbody>
            </table>
          </div>
        </div>
          
          <br>
          <br>
          <br>
          <br>
          <br>

<?php

include_once('../footer.php');

?>
 
<script src="css/jquery.js"></script>

<script src="css/bootstrap.min.js" ></script>

    <script type="text/javascript">
      $(function(){
        $(".successMessage:visible").fadeOut(5000);
      });
    </script>
  
  </body>
</html>