<?php
session_start();

$con=mysql_connect("localhost","root","");
mysql_select_db("cam_pus");

if(isset($_POST)) {


	$firstname = $_POST['fname'];
	$lastname = $_POST['lname'];
	$address = $_POST['address'];
	$city = $_POST['city'];
	$state = $_POST['state'];
	$contactno = $_POST['contactno'];
	$qualification = $_POST['qualification'];
	$stream = $_POST['stream'];
	$passingyear = $_POST['passingyear'];
	$dob = $_POST['dob'];
	$dist=$_POST['district'];
	$age = $_POST['age'];
	
	
	$sql = "UPDATE users SET fname='$firstname', lname='$lastname', address='$address', city='$city', state='$state', contactno='$contactno', qualification='$qualification', stream='$stream', passingyear='$passingyear', dob='$dob', age='$age',district='$dist' WHERE user_id='$_SESSION[user_id]'";

	if(mysql_query($sql) === TRUE) {
		header("Location: dashboard.php");
		
	} else {
		echo "Error ".$sql."<br>".$conn->error;
	}


} else {
	header("Location: dashboard.php");

}
?>