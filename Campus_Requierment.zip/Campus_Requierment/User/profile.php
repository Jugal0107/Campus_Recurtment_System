<?php
 
 include_once('../header.php');

  if(empty($_SESSION['user_id'])) {
    // header("Location: ../index.php");

}

?>

<html>
  <head>
    
  <title>User Profile</title>

 <style>
    *
    {
       border-color:black;
       size: 25px;
    }
.al1{
     font-size: 30px;
     color:purple;
     text-decoration:none;     
    }
.ti{
  text-align:center;
    font-size:20px;
    margin-right: 12%;
    color: #fff;
   }
   #main-holder{
    width: 45%;
    height:230%;
    display:grid;
    justify-items:center;
    align-items:center;
    background-color:white;
    border-radius:7px;
    box-shadow:0px 0px 5.2px 2.5px lime;
   }
   #login-form{
    align-self:flex-start;
    display:grid;
    justify-items:center;
    align-items:center;
   }
   .login-form-field::placeholder{
    color:#3a3a3a;
   }
   label{
    font-size:25px;
   }
   input{
    font-size:20px;
    position: relative;
   }
   .login-form-field{
    border:none;
    border-bottom:1px solid #3a3a3a;
    margin-bottom:10px;
    border-radius:3px;
    outline:none;
    padding:0px 0px 5px 5px;
   }
   #login-form-submit{
    width:100%;
    padding:7px;
    border:none;
    border-radius:5px;
    color:white;
    font-weight:bold;
    background-color:#3a3a3a;
    cursor:pointer;
    outline:none;
   }
   .p1{
    font-size:25px;
    font-family:arial,italic;
    font-weight:bold;
   }
   .a1{
    color:brown;
    text-decoration:0;
    font-size:20px;
   }
   .tx{
    font-size:25px;
    padding:0px;
    border-radius:7px ;
    border:2px solid #052d2d;
    width:50%;
   }
</style>
  </head>
  <body>

  <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow ">
    <div class="container-fluid">
     <a class="navbar-brand" href="../index.php">Mr.Patel's-JOB.com</a>
     <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
       <span class="navbar-toggler-icon"></span>
      </button>
      <div class="container">
        <h3 class="ti" >Candidate Profile</h3>
      </div>
      <div class="tx">
        <a class="btn btn-outline-info" href="../User/dashboard.php" style="text-decoration:none;  color:white">Dashbord</a>
        <a class="btn btn-outline-info" href="../User/profile.php" style="text-decoration:none;  color:white">Profile</a>       
        <a class="btn btn-outline-info" href="editprofile.php" style="text-decoration:none;  color:white">Edit</a>
        <a class="btn btn-outline-info" href="applied-jobs.php" style="text-decoration:none;  color:white" >My Applied Jobs</a>
      </div>
      <a class="btn btn-danger me-2" href="../logout.php">Logout</a>
    </div>
  </nav>

 <div class="container mt-4 shadow rounded" align="center">
 <form id="login-form"  class="row g-2 mt-3 mb-2 " method="post" action="updateprofile.php">
            <?php 
                $sql = "SELECT * FROM users where user_id='$_SESSION[user_id]' ";
                $result = mysql_query($sql);
                if(mysql_num_rows($result) > 0) {
                  while($row = mysql_fetch_assoc($result)) {
               ?>

<div class="card w-50">
  <div class="card-body">
    <h5 class="card-title" style="color:Blue;background-color:skyblue;font-size:25px;" ><b>Profile</b></h5>
    <hr>
    <lable><b>Name</b></lable>
    <input type="text" name="fname" class="form-control shadow " value="<?php echo $row['fname'] . " " .$row['lname']; ?>" placeholder="First Name"readonly />
    
    <lable><b>Email<readonly /b><readonly /lable>
    <input type="email" name="email" class="form-control shadow " value="<?php echo $row['email']; ?>" placeholder="Email" readonly />
   
    <lable><b>Contect</b></lable>
    <input type="number" name="contactno" class="form-control shadow " value="<?php echo $row['contactno']; ?>" placeholder="Contact No" readonly />
    
    <lable><b>Qualification</b></lable>
    <input type="text" class="form-control shadow" name="qualification" placeholder="Qualification" value="<?php echo $row['qualification']; ?>" readonly />
    
    <lable><b>Date of Birth </b></lable>
    <input type="date" class="form-control shadow" name="dob" placeholder="Date of Birth" value="<?php echo $row['dob']; ?>" readonly />
   
    <lable><b>District</b></lable>
    <textarea class="form-control shadow" name="district"  rows="4" placeholder="District" readonly ><?php echo $row['district']; ?></textarea>
    
    <lable><b>Address</b></lable>
    <textarea class="form-control shadow" name="address"  rows="4" placeholder="Address" readonly ><?php echo $row['address']; ?></textarea>
    
    <br><br>
    <a href="dashboard.php" class="mb-5 w-25 btn btn-outline-primary">Back</a>
  </div>
</div>
              
    <?php
        }
       }
     ?>
  </form>
</div>

<br>
<br>

<?php

include_once('../footer.php');

?>
 
<script src="css/jquery.js"></script>

<script src="css/bootstrap.min.js" ></script>

  </body>
</html>