<?php

include_once('../header.php');

if(empty($_SESSION['user_id'])) {
  // header("Location: ../index.php");
  
}

?>

<html>
  <head>
    
  <title>Job Details</title>
   
 <style>
    *
    {
       border-color:black;
       size: 25px;
    }
.al1{
     font-size: 30px;
     color:purple;
     text-decoration:none;     
    }
    .ti{
    text-align:center;
    font-size:20px;
    margin-right: 12%;
    color: #fff;
   }
   .tx{
    font-size:25px;
    padding:0px;
    border-radius:7px ;
    border:2px solid #052d2d;
    width:50%;
   }
   #main-holder{
    width: 50%;
    height:285%;
    display:grid;
    justify-items:center;
    align-items:center;
    background-color:white;
    border-radius:7px;
    box-shadow:0px 0px 5.2px 2.5px lime;
   }
   #login-form{
    align-self:flex-start;
    display:grid;
    justify-items:center;
    align-items:center;
   }
   .login-form-field::placeholder{
    color:#3a3a3a;
   }
   label{
    font-size:25px;
   }
   input{
    font-size:25px;
    position: relative;
    border:1px solid black;
    border-radius: 5px;
    width: 80%;
    height: 45px;
    padding: 15px; 
   }
   .login-form-field{
    border:none;
    border-bottom:1px solid #3a3a3a;
    margin-bottom:10px;
    border-radius:3px;
    outline:none;
    padding:0px 0px 5px 5px;
   }
   #btn{
    text-decoration:none;
    width:25%;
    padding:6px;
    border:none;
    border-radius:5px;
    color:white;
    font-weight:bold;
    background-color:black;
    cursor:pointer;
    outline:none;
   }
   .p1{
    font-size:25px;
    font-family:arial,italic;
    font-weight:bold;
   }
   .a1{
    color:brown;
    text-decoration:0;
    font-size:20px;
   }
   .tbl{
    font-size:25px;
    height:25px;
    width: 25px;
    border-radius:2px;
    padding:2px;
   }
   </style>
  </head>
  <body>
    
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow ">
    <div class="container-fluid">
     <a class="navbar-brand" href="../index.php">Mr.Patel's-JOB.com</a>
     <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
       <span class="navbar-toggler-icon"></span>
      </button>
      <div class="container">
        <h3 class="ti" >My Dashbord</h3>
      </div>
      <div class="tx" >
        <a class="btn btn-outline-info" href="../User/dashboard.php" style="text-decoration:none;  color:white">Dashbord</a>
        <a class="btn btn-outline-info" href="profile.php" style="text-decoration:none;  color:white">Profile</a>
        <a class="btn btn-outline-info" href="applied-jobs.php" style="text-decoration:none;  color:white" >My Applied Jobs</a>
      </div>
      <a class="btn btn-danger me-2" href="../logout.php">Logout</a>
    </div>
  </nav>
   
  <br>
  <br>

  <div class="mt-1 mb-4 container">
  <div class="row container" align="center">
  <?php 
      $sql = "SELECT * FROM job_post ";
      $result =mysql_query($sql);
        if(mysql_num_rows($result) > 0) {
          while($row =mysql_fetch_assoc($result)) {
        ?>
   
        <table class="table table-bordered table-hover mb-0" style="border:2px;" >
            <tr>
               <td>Com_Id:-</td>
               <td><?php echo $row['com_id']; ?></td>
            </tr>
            <tr>
               <td>Job Title:-</td>
               <td><?php echo $row['jobtitle']; ?></td>
            </tr> 
            <tr>  
               <td>Description:-</td>
               <td><?php echo $row['description']; ?></td>
            </tr>
            <tr>
               <td>Minimum Salary:-</td>
               <td><?php echo $row['minimumsalary']; ?></td>
            </tr>
            <tr>
               <td>Maximum Salary:-</td>
               <td><?php echo $row['maximumsalary']; ?></td>
            </tr>
            <tr>
               <td>Experience:-</td>
               <td><?php echo $row['experience']; ?></td>
            </tr>
            <tr>
               <td>Qualification:-</td>
               <td><?php echo $row['qualification']; ?></td>
            </tr>
            <span></span>
            <br>
            <tr>
               <td colspan="5px" align="center" style="padding:10px;">
               <a class="btn btn-outline-secondary" href="apply.php?id=<?php echo $row['jobpost_id']; ?>" >Apply</a>
               </td>
            </tr>
        </table>
        <br>
        <?php 
        }
      }
    ?>
     </div>
        </div>
  </div>
  

  <br>
  <br>
  <br>

<?php

include_once('../footer.php');

?>
 
<script src="css/jquery.js"></script>

<script src="css/bootstrap.min.js" ></script>


  </body>
</html>