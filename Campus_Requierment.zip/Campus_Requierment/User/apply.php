<?php
session_start();

$con=mysql_connect("localhost","root","");
mysql_select_db("cam_pus");

if(isset($_POST)) {

	$sql = "SELECT * FROM job_post WHERE jobpost_id='$_GET[id]'";
                  $result = mysql_query($sql);
                  if(mysql_num_rows($result) > 0) 
                  {
                    $row = mysql_fetch_assoc($result);
                    $id_company = $row['com_id'];
                  }
                    
    $sql1 = "SELECT * FROM apply_job_post WHERE user_id='$_SESSION[user_id]' AND jobpost_id='$row[jobpost_id]'";
    $result1 = mysql_query($sql1);
    if(mysql_num_rows($result1) == 0) {

		$sql = "INSERT INTO apply_job_post(jobpost_id, com_id, user_id) VALUES ('$_GET[id]', '$id_company', '$_SESSION[user_id]')";
		if(mysql_query($sql)===TRUE) {
			$_SESSION['jobApplySuccess'] = true;
			header("Location: dashboard.php");
			
		} else {
			echo "Error " . $sql . "<br>" . $conn->error;
		}

    } else {
		header("Location: dashboard.php");
		
}

} else {
	header("Location: dashboard.php");
	
}
?>