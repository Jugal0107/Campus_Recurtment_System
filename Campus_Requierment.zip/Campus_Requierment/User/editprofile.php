<?php
 
 include_once('../header.php');

  if(empty($_SESSION['user_id'])) {
    // header("Location: ../index.php");

}

?>

<html>
  <head>
    
  <title>User Profile</title>
   
 <style>
    *
    {
       border-color:black;
       size: 25px;
    }
.al1{
     font-size: 30px;
     color:purple;
     text-decoration:none;     
    }
.ti{
  text-align:center;
    font-size:20px;
    margin-right: 12%;
    color: #fff;
   }
   #main-holder{
    width: 45%;
    height:230%;
    display:grid;
    justify-items:center;
    align-items:center;
    background-color:white;
    border-radius:7px;
    box-shadow:0px 0px 5.2px 2.5px lime;
   }
   #login-form{
    align-self:flex-start;
    display:grid;
    justify-items:center;
    align-items:center;
   }
   .login-form-field::placeholder{
    color:#3a3a3a;
   }
   label{
    font-size:25px;
   }
   input{
    font-size:20px;
    position: relative;
   }
   .login-form-field{
    border:none;
    border-bottom:1px solid #3a3a3a;
    margin-bottom:10px;
    border-radius:3px;
    outline:none;
    padding:0px 0px 5px 5px;
   }
   #login-form-submit{
    width:100%;
    padding:7px;
    border:none;
    border-radius:5px;
    color:white;
    font-weight:bold;
    background-color:#3a3a3a;
    cursor:pointer;
    outline:none;
   }
   .p1{
    font-size:25px;
    font-family:arial,italic;
    font-weight:bold;
   }
   .a1{
    color:brown;
    text-decoration:0;
    font-size:20px;
   }
   .tx{
    font-size:25px;
    padding:0px;
    border-radius:7px ;
    border:2px solid #052d2d;
    width:50%;
   }
</style>
  </head>
  <body>

  <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow ">
    <div class="container-fluid">
     <a class="navbar-brand" href="../index.php">Mr.Patel's-JOB.com</a>
     <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
       <span class="navbar-toggler-icon"></span>
      </button>
      <div class="container">
        <h3 class="ti" >Edit Candidate Profile</h3>
      </div>
      <div class="tx">
        <a class="btn btn-outline-info" href="../User/dashboard.php" style="text-decoration:none;  color:white">Dashbord</a>
        <a class="btn btn-outline-info" href="../User/profile.php" style="text-decoration:none;  color:white">Profile</a>
        <a class="btn btn-outline-info" href="editprofile.php" style="text-decoration:none;  color:white">Edit</a>
        <a class="btn btn-outline-info" href="applied-jobs.php" style="text-decoration:none;  color:white" >My Applied Jobs</a>
      </div>
      <a class="btn btn-danger me-2" href="../logout.php">Logout</a>
    </div>
  </nav>

 <div class="container mt-4 shadow rounded" align="center">
 <form id="login-form"  class="row g-3 mt-4 mb-5 "  method="post" action="updateprofile.php">
            <?php 
                $sql = "SELECT * FROM users where user_id='$_SESSION[user_id]' ";
                $result = mysql_query($sql);
                if(mysql_num_rows($result) > 0) {
                  while($row = mysql_fetch_assoc($result)) {
               ?>
      <div class="row mt-4">
        <div class="col">
          <lable><b>First Name</b></lable>
          <input type="text" name="fname" class="form-control shadow " value="<?php echo $row['fname']; ?>" placeholder="First Name"/>
        </div>
        <div class="col">
          <lable><b>Last Name</b></lable>
          <input type="text" name="lname" class="form-control shadow" value="<?php echo $row['lname']; ?>" placeholder="Last Name"/>
        </div>
      </div>

      <div class="row mt-4">
        <div class="col">
          <lable><b>Email</b></lable>
           <input type="email" name="email" class="form-control shadow " value="<?php echo $row['email']; ?>" placeholder="Email" readonly />
        </div>
        <div class="col">
          <lable><b>Age</b></lable>
          <input type="number" class="form-control shadow" name="age" placeholder="Age" value="<?php echo $row['age']; ?>" />
        </div>
      </div>

      <div class="row mt-4">
        <div class="col">
          <lable><b>City</b></lable>
          <input type="text" name="city" class="form-control shadow " value="<?php echo $row['city']; ?>" placeholder="City"/>
        </div>
        <div class="col">
          <lable><b>State</b></lable>
          <input type="text" name="State" class="form-control shadow" value="<?php echo $row['state']; ?>" placeholder="State"/>
        </div>
      </div>

      <div class="row mt-4">
        <div class="col">
          <lable><b>Contect</b></lable>
          <input type="number" name="contactno" class="form-control shadow" minlenght="10" value="<?php echo $row['contactno']; ?>" placeholder="Contact No" />
        </div>
          <div class="col">
          <lable><b>Qualification</b></lable>
          <input type="text" class="form-control shadow" name="qualification" placeholder="Qualification" value="<?php echo $row['qualification']; ?>" required  />
        </div>
      </div>

      <div class="row mt-4">
        <div class="col">
          <lable><b>Stream</b></lable>
          <input  type="text" class="form-control shadow" name="stream" placeholder="Stream" value="<?php echo $row['stream']; ?>" required />
        </div>
        <div class="col">
          <lable><b>Passing Year</b></lable>
          <input type="year" class="form-control shadow" name="passingyear" placeholder="Passing Year" value="<?php echo $row['passingyear']; ?>" required />
        </div>
      </div>

      <div class="row mt-4">
        <div class="col">
          <lable><b>Date of Birth </b></lable>
          <input type="date" class="form-control shadow" name="dob" placeholder="Date of Birth" value="<?php echo $row['dob']; ?>" required />
        </div>

      <div class="row mt-4">
        <div class="col">
          <lable><b>District</b></lable>
          <textarea class="form-control shadow" name="district"  rows="4" placeholder="District"><?php echo $row['district']; ?></textarea>
        </div>
        <div class="col">
          <lable><b>Address</b></lable>
          <textarea class="form-control shadow" name="address"  rows="4" placeholder="Address"><?php echo $row['address']; ?></textarea>
        </div>
      </div>
  
      <br>
      <input type="submit" value="Updte" class="mb-5 w-25 btn btn-outline-primary" />
                  
     <?php
         }
       }
     ?>
  </form>
</div>

<br>
<br>

<?php

include_once('../footer.php');

?>
 
<script src="css/jquery.js"></script>

<script src="css/bootstrap.min.js" ></script>

  </body>
</html>