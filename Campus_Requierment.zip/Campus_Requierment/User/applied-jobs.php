<?php

include_once('../header.php');

if(empty($_SESSION['user_id'])) {
  // header("Location: ../index.php");
  
}

?>

<html>
  <head>
    
  <title>Applied Jobs</title>
   
 <style>
    *
    {
       border-color:black;
       size: 25px;
    }
.al1{
     font-size: 30px;
     color:purple;
     text-decoration:none;     
    }
    .d1{
     font-size: 30px;
     color:firebrick;
     text-decoration:none;
    }
.reg{
     text-align:center;
     font-size:30px;
     background-color:lightgray;
     border:red;
     position:relative;
     background-origin: padding-box;
     line-height:100px;
     width: 50%; 
     height: 120px;
     border-radius: 5px;
     color:black;
    } 
   .ti{
    text-align:center;
    font-size:20px;
    margin-right: 12%;
    color: #fff;
   }
   .tx{
    font-size:25px;
    padding:0px;
    border-radius:7px ;
    border:2px solid #052d2d;
    width:50%;
   }
   </style>
  </head>
  <body>
    
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow ">
    <div class="container-fluid">
     <a class="navbar-brand" href="../index.php">Mr.Patel's-JOB.com</a>
     <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
       <span class="navbar-toggler-icon"></span>
      </button>
      <div class="container">
        <h3 class="ti" >My Applied Jobs</h3>
      </div>
      <div class="tx" >
        <a class="btn btn-outline-info" href="../User/dashboard.php" style="text-decoration:none;  color:white">Dashbord</a>
        <a class="btn btn-outline-info" href="../User/profile.php" style="text-decoration:none;  color:white">Profile</a>
        <a class="btn btn-outline-info" href="editprofile.php" style="text-decoration:none;  color:white">Edit</a>
        <a class="btn btn-outline-info" href="applied-jobs.php" style="text-decoration:none;  color:white" >My Applied Jobs</a>
      </div>
      <a class="btn btn-danger me-2" href="../logout.php">Logout</a>
    </div>
  </nav>

<div class="container">
    <div class="form-group">
        <div class="form-body">
            <div class="user" align="center">
              <h3 class="ti" >Applied Jobs</h3>
            </div>
        </div>
    </div>
 </div>
  
  <br>
  <br>

    <div class="container">
      <div class="row" align="center">
            <table class="table table-bordered table-hover mb-0">
              <thead class="bg-dark text-white">
                <th style="text-align:center;" >Job Name</th>
                <th style="text-align:center;" >Job Description</th>
                <th style="text-align:center;" >Created At</th>
                <th style="text-align:center;" >Status</th>
              </thead>
              <tbody>
                <?php 
                  $sql = "SELECT * FROM job_post INNER JOIN apply_job_post ON job_post.jobpost_id=apply_job_post.jobpost_id WHERE apply_job_post.user_id='$_SESSION[user_id]'";
                  $result = mysql_query($sql);
                  if(mysql_num_rows($result) > 0) {
                    while($row = mysql_fetch_assoc($result)) 
                    {
                      
                     ?>
                      <tr>
                        <td ><?php echo $row['jobtitle']; ?></td>
                        <td ><?php echo $row['description']; ?></td>
                        <td ><?php echo date("d-M-Y", strtotime($row['createdAt'])); ?></td>
                        <td ><?php 
                        if($row['status'] == 0) {
                          echo "Pending";
                        } else if($row['status'] == 1 ) {
                          echo "Rejected";
                        } else {
                          echo "Accepte";
                        }
                        ?>
                      </td>
                      </tr>
                     <?php
                    }
                  }
                  
                ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <br>
    <br>

<?php

include_once('../footer.php');

?>
 
<script src="css/jquery.js"></script>

<script src="css/bootstrap.min.js" ></script>

</body>
</html>