<?php
session_start();

$con=mysql_connect("localhost","root","");
mysql_select_db("cam_pus");

if(isset($_POST)) {
	
	$email = $_POST['email'];
	$newpassword = $_POST['newpassword'];
	
	$sql = "SELECT email FROM company WHERE email='$email'";
	$result = mysql_query($sql);
	if(mysql_num_rows($result) > 0) {
		$newPass = $newpassword;
		
		$password = base64_encode(strrev(md5($newPass)));
		
		$sql = "UPDATE company SET password='$password' WHERE email='$email'";
		if(mysql_query($sql)===TRUE) {

			$_SESSION['passwordChanged'] = $newPass;
			echo "<script>
			      alert('Password Reset Successfully.')
			      window.location='company-login.php'
				  </script>";
			// header("Location: company-login.php");
			
		} else {
			echo "Error " . $sql . "<br>" . $conn->error;
		}
	} else {
		
		$_SESSION['emailNotFoundError'] = true;
		echo "<script>
			      alert('Invalid format!')
			      window.location='companyforgot-password.php'
				  </script>";
		// header("Location: companyforgot-password.php");
		
	}
	
} else {
	
	header("Location: companyforgot-password.php");
	
}
?>