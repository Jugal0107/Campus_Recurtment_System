<?php

include_once('header.php');

$jobpost_id=$_REQUEST['jobpost_id'];
$jobtitle=$_REQUEST['jobtitle'];
$description=$_REQUEST['description'];
$minimumsalary=$_REQUEST['minimumsalary'];
$maximumsalary=$_REQUEST['maximumsalary'];
$experience=$_REQUEST['experience'];
$qualification=$_REQUEST['qualification'];

$sql="select * from job_post";
$result=mysql_query($sql);


?>

<html>

  <head>

    <title>Search for Jobs</title>
    
 <style>
    *
    {
      margin:0px;
      padding:0px;
    }
.ti{
    text-align:center;
    font-size:20px;
    margin-right: 12%;

    color: #fff;
   }     
   #login-form{
    align-self:flex-start;
    display:grid;
    justify-items:center;
    align-items:center;
    font-size:30px;
   }
   select{
    font-size:10px;
   }
  .titale{
    font-size:25px
  }
   .form{
    margin-left: 25%;
   }
   .shadow{
    color:blue;
    padding:2px;
    font-size:18px;
   }
</style>

</head>
<body>

 <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow " style="height:60px;">
   <div class="container-fluid">
     <a class="navbar-brand" href="index.php">Mr.Patel's-JOB.com</a>
     <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
       <span class="navbar-toggler-icon"></span>
      </button>
    <div class="container">
      <h3 class="ti" >Find Your Dream Job</h3>
    </div>
      <a href="index.php" class="btn btn-outline-warning me-3">Back</a>
  </div>
</nav>

<br>
<br>
<br>

 <center><input class="pt-2 w-25 pb-2" type="text" id="skill" onKeyUp="skill()" autofocus placeholder="Search by Price.."  ></center>
  <!-- <br> -->
  <hr>
  <table  id="search" width="100%" height="130" border="1" cellpadding="0" cellspacing="0">
    <tr bgcolor="#9a9a9a" class="shadow"  >
      <th width="25px"  scope="row"><div align="justify">Job Description </div></th>
      <th width="25px"  ><div align="justify">Job Name</div></th>
      <th width="25px"  ><div align="center">Minimum Salary</div></th>
      <th width="25px" colspan="1.5px"  ><div align="center">Maximum Salary</div></th>
      <th width="25px"  ><div align="center">Experience</div></th>
      <th width="25px"  ><div align="center">Qualification</div></th>
      <th width="25px"  ><div align="center">Action</div></th>
    </tr>
    <?php 
  while($row=mysql_fetch_array($result))
  {
  ?>
    <tr>
      <td height="70" scope="row"><div align="left"><b><?php echo $row['description']; ?></b></div></td>
      <td><div align="left" ><b><?php echo  $row['jobtitle']; ?></b></div></td>
      <td><div align="center"><b><?php echo $row['minimumsalary']; ?></b></div></td>
      <td><div align="center"><b><?php echo $row['maximumsalary']; ?></b></div></td>
      <td><div align="center"><b><?php echo $row['experience']; ?></b></div></td>
      <td><div align="center"><b><?php echo $row['qualification']; ?></b></div></td>
      <td><div align="center"><a href="apply-job-post.php" class="btn btn-outline-primary">Apply</a></div></td>
      
   </tr>
    <?php
  }
  mysql_free_result($result);
  ?>
  </table>
  <br>
<br>
  
</div>
</body>

<script>

function skill() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("skill");
  filter = input.value.toUpperCase();
  table = document.getElementById("search");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}

</script>

<br>
<br>
<br>
  
<?php

include_once('footer.php');

?>

  <script src="css/jquery.js"></script>
  <script src="csss/bootstrap.min.js" ></script>

  <script type="text/javascript">
    $(function() {
      var oTable = $('#myTable').DataTable({
        "autoWidth" : false,
        "ajax" : {
          "url" : "refresh_job_search.php",
          "$json" : function (d) {
            d.experience = $("#experience").val();
            d.qualification = $("#qualification").val();
          }
        }
      });

      $("#myForm").on("submit", function(e) {
        e.preventDefault();
        oTable.ajax.reload( null, false);
      })

    });
  </script>
    
  
  </body>
</html>