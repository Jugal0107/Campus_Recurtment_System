<?php
session_start();

$con=mysql_connect("localhost","root","");
mysql_select_db("cam_pus");


if(isset($_REQUEST["term"]))
{
  $sql="SELECT * FROM job_post where qualification LIKE ?";

  if($stmt=mysql_prepare($con,$sql))
  {
    mysql_stmt_bind_param($stmt,"s",$param_term);

    $param_term=$_REQUEST["term"].'%';

    if(mysql_stmt_execute($stmt))
    {
      $result=mysql_stmt_get_result($stmt);

      if(mysql_num_rows($result)>0)
      {
        while($row=mysql_fetch_array($result))
        {
          echo $row['jobtitle']; 
	      	echo $row['description']; 
	      	echo $row['minimumsalary']; 
	      	echo $row['maximumsalary']; 
	      	echo $row['experience'];
	      	echo $row['qualification'];
	      	echo $apply;
        }
        else{
          echo "<p>No Found<p>";
        }
      }
      else{
        echo "ERROR:Could not able to execute $sql".mysql_error($con);
      }
    }
    
  }
}


?>