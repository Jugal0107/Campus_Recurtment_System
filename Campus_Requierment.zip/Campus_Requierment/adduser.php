<?php
session_start();

$con=mysql_connect("localhost","root","");
mysql_select_db("cam_pus");

if(isset($_POST)) {
	
	$firstname = $_POST['fname'];
	$lastname = $_POST['lname'];
	$address = $_POST['address'];
	$city = $_POST['city'];
	$state = $_POST['state'];
	$contactno = $_POST['contactno'];
	$qualification = $_POST['qualification'];
	$stream = $_POST['stream'];
	$passingyear = $_POST['passingyear'];
	$dob = $_POST['dob'];
	$age = $_POST['age'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$designation=$_POST['designation'];
    	
	$password = base64_encode(strrev(md5($password)));
	
    $sql = "SELECT email FROM users WHERE email='$email'";
	$result = mysql_query($sql);
	
	if(mysql_num_rows($result) == 0) {
	$uploadOk = true;


	if($uploadOk == false) {
		header("Location: register.php");

	}
		$hash = md5(uniqid());

		$sql = "INSERT INTO users(fname, lname, email, password, address, city, state, contactno, qualification, stream, passingyear, dob, age, designation) VALUES ('$firstname', '$lastname', '$email', '$password', '$address', '$city', '$state', '$contactno', '$qualification', '$stream', '$passingyear', '$dob','$age','$designation')";
		if(mysql_query($sql)===TRUE) {
		
			$_SESSION['registerCompleted'] = true;
            echo "
            <script>
             alert('User Register Successfully.');
             window.location='login.php';
            </script>
            ";
			// header("Location: login.php");
			
		} else {
			echo "Error " . $sql . "<br>" . $conn->error;
		}
	} else {
		
        $_SESSION['registerError'] = true;
        echo "
    <script>
     alert('Something ! Went Wrong!....');
     window.location='register.php';
    </script>
    ";
		// header("Location: register.php");
		
	}
	
} else {
	header("Location: register.php");
	
}
?>