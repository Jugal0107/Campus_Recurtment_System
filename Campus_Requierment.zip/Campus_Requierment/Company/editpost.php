<?php
session_start();

$con=mysql_connect("localhost","root","");
mysql_select_db("cam_pus");

if(isset($_POST)) {

	$jobtitle = $_POST['jobtitle'];
	$description = $_POST['description'];
	$minimumsalary = $_POST['minimumsalary'];
	$maximumsalary = $_POST['maximumsalary'];
	$experience = $_POST['experience'];
	$qualification = $_POST['qualification'];
	$sql = "UPDATE job_post SET jobtitle='$jobtitle', description='$description', minimumsalary='$minimumsalary', maximumsalary='$maximumsalary', experience='$experience', qualification='$qualification' WHERE jobpost_id='$_POST[target_id]' AND com_id='$_SESSION[user_id]'";
	if(mysql_query($sql)===TRUE) {
		$_SESSION['jobPostUpdateSuccess'] = true;
		header("Location: dashboard.php");
		
	} else {
		echo "Error " . $sql . "<br>" . $conn->error;
	}
	
} else {
	header("Location: dashboard.php");
	
}
?>