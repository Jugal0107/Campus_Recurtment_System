<?php

include_once('../header.php');

if(empty($_SESSION['user_id'])) {
//  header("Location: ../index.php");

}

?>

<html>
  <head>
    
  <title>View Job Posts</title>

 <style>
    *
    {
       border-color:black;
       size: 25px;
    }
.al1{
     font-size: 30px;
     color:purple;
     text-decoration:none;     
    }
    .d1{
     font-size: 30px;
     color:firebrick;
     text-decoration:none;
    }
.ti{
    text-align:center;
    font-size:20px;
    margin-right: 12%;
    color: #fff;
   }
   .tx{
    font-size:25px;
    padding:5px;
    border-radius:7px ;
    border:2px solid #052d2d;
    width:50%;
   }
   </style>
  </head>
  <body>
    
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow ">
    <div class="container-fluid">
     <a class="navbar-brand" href="../index.php">Mr.Patel's-JOB.com</a>
     <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
       <span class="navbar-toggler-icon"></span>
      </button>
      <div class="container">
        <h3 class="ti" >Company Dashbord</h3>
      </div>
    </div>
    <div class="tx" >
    <a class="btn btn-outline-primary me-2" href="dashboard.php" style="text-decoration:none; color:white;">Dashboard</a>
        <a class="btn btn-outline-primary" href="create-job-post.php" style="text-decoration:none; color:white;" >Create Job Post</a>
        <a class="btn btn-outline-primary" href="view-job-post.php" style="text-decoration:none; color:white;"  >View Job Post</a>
      </div>
   <a href="../logout.php"  class="btn btn-danger me-2">Logout</a>
  </nav>


<div class="mt-5 ms-3 me-3">
    <div class="row" align="center">
        <table class="table table-bordered table-hover mb-0">
            <thead class="bg-dark text-white">
                <th style="text-align:center;">Job Name</th>
                <th style="text-align:center;">Job Description</th>
                <th style="text-align:center;">Minimum Salary</th>
                <th style="text-align:center;">Maximum Salary</th>
                <th style="text-align:center;">Experience</th>
                <th style="text-align:center;">Qualification</th>
                <th style="text-align:center;">Created At</th>
                <th style="text-align:center;">Action</th>
            </thead>
            <tbody>
                <?php 
                  $sql = "SELECT * FROM job_post where com_id='$_SESSION[user_id]' ";
                  $result = mysql_query($sql);
                  if(mysql_num_rows($result) > 0) {
                    while($row = mysql_fetch_assoc($result)) 
                    {
                     ?>
                      <tr>
                        <td style="text-align:center;"><?php echo $row['jobtitle']; ?></td>
                        <td style="text-align:center;"><?php echo $row['description']; ?></td>
                        <td style="text-align:center;"><?php echo $row['minimumsalary']; ?></td>
                        <td style="text-align:center;"><?php echo $row['maximumsalary']; ?></td>
                        <td style="text-align:center;"><?php echo $row['experience']; ?></td>
                        <td style="text-align:center;"><?php echo $row['qualification']; ?></td>
                        <td style="text-align:center;"><?php echo date("d-M-Y", strtotime($row['createdAt'])); ?></td>
                        <td style="text-align:center;"><a class="btn btn-outline-success" href="edit-job-post.php?id=<?php echo $row['jobpost_id']; ?>">Edit</a>&nbsp;&nbsp;
                            <a class="btn btn-outline-danger" href="delete-job-post.php?id=<?php echo $row['jobpost_id']; ?>" onClick="return msg() " >Delete</a></td>
                      </tr>
                     <?php
                    }
                  }
 
                ?>
            </tbody>
        </table>
    </div>
</div>
<div>
</div>

    <br>
    <br>

<?php

include_once('../footer.php');

?>
 
 
<script>
function msg()
{
  return  confirm("Are You Sure You Have Delete This Row...??");
  
}
</script>

<script src="css/jquery.js"></script>

<script src="css/bootstrap.min.js" ></script>

</body>
</html>