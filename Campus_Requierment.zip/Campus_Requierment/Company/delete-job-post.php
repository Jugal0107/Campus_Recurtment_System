<?php
session_start();

$con=mysql_connect("localhost","root","");
mysql_select_db("cam_pus");

if(isset($_POST)) {
	
	$sql = "DELETE FROM job_post WHERE jobpost_id='$_GET[id]' AND com_id='$_SESSION[user_id]'";
	if(mysql_query($sql)===TRUE) {
		$_SESSION['jobPostDeleteSuccess'] = true;
		header("Location: dashboard.php");
		
	} else {
		echo "Error " . $sql . "<br>" . mysql_error();
	}
	
} else {
	header("Location: dashboard.php");

}
?>