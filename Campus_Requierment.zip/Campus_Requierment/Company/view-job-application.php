<?php

include_once('../header.php');

if(empty($_SESSION['user_id'])) {
  // header("Location: ../index.php");

}

?>

<html>
  <head>
    
  <title>Application Details</title>

<style>
    *
    {
       border-color:black;
       size: 25px;
    }
.al1{
     font-size: 30px;
     color:purple;
     text-decoration:none;     
    }
    .d1{
     font-size: 30px;
     color:firebrick;
     text-decoration:none;
    }
    .d2{
     font-size: 30px;
     color:firebrick;
     text-decoration:none;
    }
.ti{
    text-align:center;
    font-size:50px;
    background-color:skyblue;
   }
   #btn{
    text-decoration:none;
    width:25%;
    padding:6px;
    border:none;
    border-radius:5px;
    color:white;
    font-weight:bold;
    background-color:black;
    cursor:pointer;
    outline:none;
   }
   #btn:hover{
    text-decoration:none;
    width:25%;
    padding:6px;
    border:none;
    border-radius:5px;
    color:#0a0a00;
    font-weight:bold;
    background-color:#9a6a6a;
    cursor:pointer;
    outline:none;
   }
   </style>
  </head>
  <body>
  
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow ">
    <div class="container-fluid">
     <a class="navbar-brand" href="../index.php">Mr.Patel's-JOB.com</a>
     <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
       <span class="navbar-toggler-icon"></span>
      </button>
      <div class="container">
        <h3 style="color:white;text-align:center" >Application Details</h3>
      </div>
    </div>
    <div class="tx" >
    <a class="btn btn-outline-primary me-2" href="dashboard.php" style="text-decoration:none; color:white;">Dashboard</a>
        <a class="btn btn-outline-primary" href="create-job-post.php" style="text-decoration:none; color:white;" >Create Job Post</a>
        <a class="btn btn-outline-primary" href="view-job-post.php" style="text-decoration:none; color:white;"  >View Job Post</a>
      </div>
   <a href="../logout.php"  class="btn btn-danger me-2">Logout</a>
  </nav>
  
  <br>
  <br>

    <div class="container">
      <div class="row" align="center">
        <table style="width: 100%;">
          <thead>
            <th style="font-size: 20px; color: #053a5a">Job Post Name</th>
            <th style="font-size: 20px; color: #053a5a">Job Description</th>
            <th style="font-size: 20px; color: #053a5a">User Name</th>
            <th style="font-size: 20px; color: #053a5a">Action</th>
          </thead>
             <tr>
                <td colspan="8"><hr style="border-color: black;"></td>
             <tr>
          <tbody>
            <?php
              $sql ="SELECT * FROM apply_job_post INNER JOIN job_post ON apply_job_post.jobpost_id=job_post.jobpost_id INNER JOIN users ON apply_job_post.user_id=users.user_id WHERE apply_job_post.com_id='$_SESSION[user_id]' AND apply_job_post.status='0'";
              $result=mysql_query($sql);
              if(mysql_num_rows($result) > 0) {
                while($row = mysql_fetch_assoc($result)) {
                  ?>
                    <tr>
                      <td style="text-align:left; font-size: 20px;"><?php echo $row['jobtitle']; ?></td>
                      <td style="text-align:left; font-size: 20px;"><?php echo $row['description']; ?></td>
                      <td style="text-align:left; font-size: 20px;"><?php echo $row['fname'] . " " . $row['lname']; ?></td>
                      <td style="text-align:left; font-size: 20px;"><a class="btn btn-primary shadow href="view-application.php?user_id=<?php echo $row['user_id']; ?>&jobpost_id=<?php echo $row['jobpost_id']; ?>">View</a></td>
                    </tr>
                  <?php
                }
               }
            ?>
          </tbody>
        </table>
      </div>
    </div>

    <br>
    <br>
    <br>
    <br>
    <br>
    
<?php

include_once('../footer.php');
?>
 
<script src="css/jquery.js"></script>

<script src="css/bootstrap.min.js" ></script>

     <script type="text/javascript">
      $(function() {
        $(".successMessage:visible").fadeOut(2000);
      });
    </script>
  </body>
</html>