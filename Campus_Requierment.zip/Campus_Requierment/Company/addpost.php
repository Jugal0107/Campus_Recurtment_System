<?php
session_start();

$con=mysql_connect("localhost","root","");
mysql_select_db("cam_pus");

if(isset($_POST)) {
	
	$jobtitle = $_POST['jobtitle'];
	$description = $_POST['description'];
	$minimumsalary = $_POST['minimumsalary'];
	$maximumsalary = $_POST['maximumsalary'];
	$experience = $_POST['experience'];
	$qualification = $_POST['qualification'];
	$sql = "INSERT INTO job_post(com_id, jobtitle, description, minimumsalary, maximumsalary, experience, qualification) VALUES ('$_SESSION[user_id]','$jobtitle', '$description', '$minimumsalary', '$maximumsalary', '$experience', '$qualification')";
	if(mysql_query($sql)===TRUE) {
		$_SESSION['jobPostSuccess'] = true;
        
		header("Location: dashboard.php");
		
	} else {
		echo "Error " . $sql . "<br>" . $conn->error;
	}
	
} else {
	header("Location: dashboard.php");
	
}
?>