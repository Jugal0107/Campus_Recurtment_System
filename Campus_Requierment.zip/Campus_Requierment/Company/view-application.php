<?php

include_once('../header.php');

if(empty($_SESSION['user_id'])) {
  // header("Location: ../index.php");
  
}

?>

<html>
  <head>
     <title>User Application</title>

<style>
    *
    {
       border-color:black;
       size: 25px;
    }
.al1{
     font-size: 30px;
     color:purple;
     text-decoration:none;     
    }
    .d1{
     font-size: 30px;
     color:firebrick;
     text-decoration:none;
    }
    .d2{
     font-size: 30px;
     color:firebrick;
     text-decoration:none;
    } 
   </style>
  </head>
  <body>

  <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow ">
    <div class="container-fluid">
     <a class="navbar-brand" href="../index.php">Mr.Patel's-JOB.com</a>
     <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
       <span class="navbar-toggler-icon"></span>
      </button>
      <div class="container">
        <h3 style="color:white;text-align:center;" >View User Application</h3>
      </div>
    </div>
    <div class="tx" >
    <a class="btn btn-outline-primary me-2" href="dashboard.php" style="text-decoration:none; color:white;">Dashboard</a>
        <a class="btn btn-outline-primary" href="create-job-post.php" style="text-decoration:none; color:white;" >Create Job Post</a>
        <a class="btn btn-outline-primary" href="view-job-post.php" style="text-decoration:none; color:white;"  >View Job Post</a>
      </div>
   <a href="../logout.php"  class="btn btn-danger me-2">Logout</a>
  </nav>
   
  <br>
  <br>

    <div class="container">
      <div class="row">
        <div class="panel panel-info">
          <div class="panel-body" style="background-color:lightgray;font-size: 20px; border: 2px solid #053a5a;">
            <?php
              $sql ="SELECT * FROM apply_job_post INNER JOIN users ON apply_job_post.user_id=users.user_id WHERE apply_job_post.user_id='$_GET[user_id]' AND apply_job_post.jobpost_id='$_GET[jobpost_id]'";
              $result=mysql_query($sql);
              if(mysql_num_rows($result) > 0) {
                while($row = mysql_fetch_assoc($result)) {
              ?>

              <table class="table">

                <div style="color:green;background-color:lightgray;" class=" mt-3">
                     <h3 align="center">View User Application</h3>
                </div>

                <tr>
                  <td>Name</td>
                  <td>:</td>
                  <td><?php echo $row['fname'] . " " . $row['lname']; ?></td>
                </tr>

                <tr>
                  <td colspan="3"><br></td>
                </tr>

                <tr>
                  <td>Email</td>
                  <td>:</td>
                  <td><?php echo $row['email']; ?></td>
                </tr>

                <tr>
                  <td colspan="3"><br></td>
                </tr>

                <tr>
                  <td>Address</td>
                  <td>:</td>
                  <td><?php echo $row['address']; ?></td>
                </tr>

                <tr>
                  <td colspan="3"><br></td>
                </tr>

                <tr>
                  <td>City</td>
                  <td>:</td>
                  <td><?php echo $row['city']; ?></td>
                </tr>

                <tr>
                  <td colspan="3"><br></td>
                </tr>

                <tr>
                  <td>State</td>
                  <td>:</td>
                  <td><?php echo $row['state']; ?></td>
                </tr>

                <tr>
                  <td colspan="3"><br></td>
                </tr>

                <tr>
                  <td>Contact No</td>
                  <td>:</td>
                  <td><?php echo $row['contactno']; ?></td>
                </tr>

                <tr>
                  <td colspan="3"><br></td>
                </tr>

                <tr>
                  <td>Qualification</td>
                  <td>:</td>
                  <td><?php echo $row['qualification']; ?></td>
                </tr>

                <tr>
                  <td colspan="3"><br></td>
                </tr>

                <tr>
                  <td>Stream</td>
                  <td>:</td>
                  <td><?php echo $row['stream']; ?></td>
                </tr>

                <tr>
                  <td colspan="3"><br></td>
                </tr>

                <tr>
                  <td>Passing Year</td>
                  <td>:</td>
                  <td><?php echo $row['passingyear']; ?></td>
                </tr>

                <tr>
                  <td colspan="3"><br></td>
                </tr>

                <tr>
                  <td>Date Of Birth&nbsp;&nbsp;&nbsp;</td>
                  <td>:&nbsp;&nbsp;&nbsp;</td>
                  <td><?php echo $row['dob']; ?></td>
                </tr>

                <tr>
                  <td colspan="3"><br></td>
                </tr>

                <tr>
                  <td>Designation</td>
                  <td>:</td>
                  <td><?php echo $row['designation']; ?></td>
                </tr>

              </table>

              <br>

                <?php
                if(isset($row['resume'])) {
                  ?>
                  <!-- <a href="../uploads/resume/<?php echo $row['resume']; ?>" class="btn btn-success" download="<?php echo $row['firstname']; ?>" style="font-size: 20px;">Download Resume</a> -->
                  <?php
                }
                ?>
             
                <div align="center"><a href="reject-user.php?user_id=<?php echo $_GET['user_id']; ?>&jobpost_id=<?php echo $row['jobpost_id']; ?>" class="btn btn-danger" style="font-size: 20px;">Reject User</a></div>
                <br>
                <div align="center"><a href="accept-user.php?user_id=<?php echo $_GET['user_id']; ?>&jobpost_id=<?php echo $row['jobpost_id']; ?>" class="btn btn-success" style="font-size: 20px;">Accept User</a></div>
              
                <br>

              <?php } } ?>
              <br>
          </div>
        </div>
      </div>
    </div>

    <br>
    <br>
    <br>
    <br>
    <br>

<?php

include_once('../footer.php');

?>
 
<script src="css/jquery.js"></script>

<script src="css/bootstrap.min.js" ></script>

     <script type="text/javascript">
      $(function() {
        $(".successMessage:visible").fadeOut(2000);
      });
    </script>
  </body>
</html>