<?php
session_start();

$con=mysql_connect("localhost","root","");
mysql_select_db("cam_pus");

$sql = "UPDATE apply_job_post SET status='0' WHERE jobpost_id='$_GET[jobpost_id]' AND user_id='$_GET[user_id]'";
if(mysql_query($sql) === TRUE) {
	header("Location: company.php");

} else {
	echo "Error!";
}
?>