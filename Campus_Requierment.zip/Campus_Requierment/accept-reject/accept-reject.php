<th>Resolution</th>
 <td>
  <select >
    <option ><a href="reject-user.php?id=<?php echo $row['com_id']; ?>">Accept</a></option>
    <option><a href="reject-user.php?id=<?php echo $row['com_id']; ?>">Reject</a></option>
  </select>
 </td>