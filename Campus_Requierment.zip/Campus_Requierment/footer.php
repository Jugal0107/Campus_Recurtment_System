<footer id="footer" class="fixed-bottom" style="background-color: #053a5a; height: 80px; ">

<p style="color:white; font-size: 20px; line-height: 80px; text-align: center;"> 
  Copyright &copy; 2022-2023 <a href="index.php" style="color:white;">Mr.Patel's-JOB.com </a>
</p>

</footer>