<?php
session_start();

$con=mysql_connect("localhost","root","");
mysql_select_db("cam_pus");

if(isset($_GET)) {

	$sql = "SELECT * FROM job_post WHERE jobpost_id='$_GET[id]'";
                  $result =mysql_query($sql);
                  if($result->num_rows > 0) 
                  {
                    $row = $result->fetch_assoc();
                    $id_company = $row['com_id'];
                  }
                    
    $sql1 = "SELECT * FROM apply_job_post WHERE user_id='$_SESSION[user_id]' AND jobpost_id='$row[jobpost_id]'";
    $result1 =mysql_query($sql1);
    if($result1->num_rows == 0) {

		$sql = "INSERT INTO apply_job_post(jobpost_id, com_id,user_id) VALUES ('$_GET[id]', '$id_company', '$_SESSION[user_id]')";
		if(mysql_query($sql)===TRUE) {
			$_SESSION['jobApplySuccess'] = true;
			header("Location: user/dashboard.php");
			exit();
		} else {
			echo "Error " . $sql . "<br>" . $conn->error;
		}

    } else {
		header("Location: user/dashboard.php");
		
}

} else {
	header("Location: user/dashboard.php");
	
}
?>