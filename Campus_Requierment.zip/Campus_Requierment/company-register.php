<?php
 
 include_once('header.php');

  if(isset($_SESSION['user_id'])) {
    // header("Location: user/dashboard.php");
    
  }

?>

<html lang="en">
  <head>
  
    <title>Company Registration</title>
 
 <style>
    *
    {
       border-color:black;
       size: 25px;
    }
.al1{
     font-size: 30px;
     color:purple;
     text-decoration:none;     
    }
.ti{
  text-align:center;
    font-size:20px;
    margin-right: 12%;
    color: #fff;
   }     
   #main-holder{
    width: 55%;
    height: 140%;
    display:grid;
    justify-items:center;
    align-items:center;
    background-color:white;
    border-radius:7px;
    box-shadow:0px 0px 5.2px 2.5px lime;
   }
   .login-form-field::placeholder{
    color:#3a3a3a;
   }
   label{
    font-size:25px;
   }
   input{
    font-size:20px;
    position: relative;
   }
   .login-form-field{
    border:none;
    border-bottom:1px solid #3a3a3a;
    margin-bottom:10px;
    border-radius:3px;
    outline:none;
    padding:0px 0px 5px 5px;
   }
   .p1{
    font-size:25px;
    font-family:arial,italic;
    font-weight:bold;
   }
   .a1{
    color:brown;
    text-decoration:0;
    font-size:20px;
   }
</style>


<script>
function validate() {
 var name = document.forms["myform"]["com_name"].value;
 if(name==""){
 alert("Please enter the Company name");
 return false;
 }
 var name = document.forms["myform"]["headofficecity"].value;
 if(name==""){
 alert("Please enter the Headoffice");
 return false;
 }
 var mobile = document.forms["myform"]["contactno"].value;
 if(mobile==""){
 alert("Please enter the Phone Number");
 return false;
 }else{
  var m=/^\d{10}$/;
  var mb=m.test(mobile);
 if(mb){
 }
 else{
 alert("Phone number is Invalid");
 return false;
 }
 } 
 var website = document.forms["myform"]["website"].value;
 if(website==""){
 alert("Please enter the website");
 return false;
 }else{
 var re = /^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/w \.-]*)*\/?$/;
 var x=re.test(website);
 if(x){
 }else{
 alert("website is not in correct format");
 return false;
 } 
 } 
 var comt=document.forms['myform']['com_type'].value;
 if(comt==""){
  alert("Please enter the Comany Type");
  return false;
 }
 var email = document.forms["myform"]["email"].value;
 if(email==""){
 alert("Please enter the email");
 return false;
 }else{
 var re = /^(?:[a-z0-9!#$%&amp;'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&amp;'*+/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])$/;
 var x=re.test(email);
 if(x){
 }else{
 alert("Email id not in correct format");
 return false;
 } 
 } 
 var password = document.forms["myform"]["password"].value;
 if(password==""){
 alert("Please enter the password");
 return false;
 }else{
 var re = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,10}$/;
 var x=re.test(password);
 if(x){
 }else{
 alert("Invalid format password");
 return false;
 } 
 } 
}
</script>

</head>

<body>

<nav id="sticky" class="navbar navbar-expand-lg navbar-dark bg-dark shadow ">
    <div class="container-fluid">
     <a class="navbar-brand" href="index.php">Mr.Patel's-JOB.com</a>
     <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
       <span class="navbar-toggler-icon"></span>
      </button>
    <div class="container">
      <h3 class="ti" >SignUp for Company </h3>
    </div>
    <a href="mainregister.php" class="btn btn-outline-warning ms-1">Back</a>
  </div>
</nav>

 <div class="form-group">
    <div class="form-body">
        <div class="form-panel">
            <div class="nav-bar">
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">     
          <ul class="nav navbar-nav navbar-right">
          <?php
          if(isset($_SESSION['user_id']) && empty($_SESSION['companyLogged'])) {
            ?>
            <li style="padding-right: 25px;"><a href="user/dashboard.php" style="font-size: 35px; color: #053a5a; line-height: 42px; text-decoration:none;">Dashboard</a></li>
            <li style="padding-right: 25px;"><a href="logout.php" style="font-size: 35px; color: #053a5a; line-height: 42px; text-decoration:none;">Logout</a></li>
            <?php 
            } else if(isset($_SESSION['user_id']) && isset($_SESSION['companyLogged'])){
            ?>
            <li style="padding-right: 25px;"><a href="company/dashboard.php" style="font-size: 35px; color: #053a5a; line-height: 42px; text-decoration:none;">Dashboard</a></li>
            <li style="padding-right: 25px;"><a href="logout.php" style="font-size: 35px; color: #053a5a; line-height: 42px; text-decoration:none;">Logout</a></li>
            <?php } else { 
            ?>
            <li style="padding-right: 25px;"><a href="search.php" style="font-size: 35px; color: #053a5a;text-decoration:none; line-height: 42px; text-decoration:none;">Search for Jobs</a></li>
            <li style="padding-right: 25px;"><a href="mainregister.php" style="font-size: 35px; color: #053a5a; text-decoration:none; line-height: 42px; text-decoration:none;">Register</a></li>
            <li style="padding-right: -25px;"><a href="mainlogin.php" style="font-size: 35px; color: #053a5a; text-decoration:none; line-height: 42px; ">Login</a></li>
          <?php } ?>
          </ul>
        </div>
            </div>
        </div>
    </div>
 </div>

  <div class="container mt-4" align="center">
   <form id="login-form mt-4" class="shadow row g-3 mt-4 " name="myform" onsubmit="return validate()" method="post" action="addcompany.php">
    <div class="row mt-4">
      <div class="col">
      <input type="text" class="form-control shadow " id="companyname" name="com_name" placeholder="Company Name " />
      </div>
      <div class="col">
       <input type="text" class="form-control shadow" id="headofficecity" name="headofficecity" placeholder="Head Office City "  />
      </div>
    </div>

    <div class="row mt-4">
      <div class="col">
       <input type="text" class="form-control shadow "  id="contactno" min="0"  maxlength="10" name="contactno" placeholder="Contact Number"  />
      </div>
      <div class="col">
       <input type="text" class="form-control shadow" id="website" name="website" placeholder="Website"  />
      </div>
    </div>

    <div class="row mt-4">
      <div class="col">
        <input type="text" class="form-control shadow "  id="companytype" name="com_type" placeholder="Company Type"  />
      </div>
      <div class="col">
        <input type="text" class="form-control shadow" id="email" name="email" placeholder="Email Address "  />
      </div>
    </div>

    <div class="row mt-4">
      <center><div class="col-6">
        <input type="password" class="form-control shadow "id="password" name="password" placeholder="Password "  />
      </div></center>
    </div>

    <center><input type="submit" class="mt-5 mb-5 w-25 btn btn-outline-primary" value="Sign Up" ></center>
    <?php
          if(isset($_SESSION['registerError'])){                
             ?>
          <div>
          <p style="text-align: center; color: red; font-size: 28px;">Email already Exists!</p>
          </div>
          <?php
          unset($_SESSION['registerError']);}
          ?>
  </form>
</div>  

<?php

include_once('footer.php');

?>


    <script src="css/jquery.js"></script>
    <script src="css/bootstrap.min.js" ></script>
  
    <script type="text/javascript">
      $(function(){
        $("#successMessage:visible").fadeOut(5000);
      });

    </script>

  </body>
</html>