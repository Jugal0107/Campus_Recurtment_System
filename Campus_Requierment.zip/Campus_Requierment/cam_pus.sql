-- phpMyAdmin SQL Dump
-- version 2.9.2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Nov 07, 2024 at 03:48 AM
-- Server version: 5.0.27
-- PHP Version: 5.2.1
-- 
-- Database: `cam_pus`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `admin`
-- 

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL auto_increment,
  `admin` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY  (`admin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `admin`
-- 

INSERT INTO `admin` (`admin_id`, `admin`, `password`) VALUES 
(1, 'Admin123', '123'),
(2, 'Patel017', '017');

-- --------------------------------------------------------

-- 
-- Table structure for table `apply_job_post`
-- 

CREATE TABLE `apply_job_post` (
  `apply_id` int(11) NOT NULL auto_increment,
  `jobpost_id` int(11) NOT NULL,
  `com_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` int(11) NOT NULL default '0',
  PRIMARY KEY  (`apply_id`),
  KEY `jobpost_id` (`jobpost_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `apply_job_post`
-- 

INSERT INTO `apply_job_post` (`apply_id`, `jobpost_id`, `com_id`, `user_id`, `status`) VALUES 
(1, 1, 2, 1, 1),
(2, 1, 2, 2, 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `company`
-- 

CREATE TABLE `company` (
  `com_id` int(11) NOT NULL auto_increment,
  `com_name` varchar(255) NOT NULL,
  `headofficecity` varchar(255) NOT NULL,
  `contactno` varchar(255) NOT NULL,
  `website` varchar(255) NOT NULL,
  `com_type` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `createdAt` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`com_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `company`
-- 

INSERT INTO `company` (`com_id`, `com_name`, `headofficecity`, `contactno`, `website`, `com_type`, `email`, `password`, `createdAt`) VALUES 
(1, 'Tata Motors Vehicle Manufacturing', 'Pune,Maharashtra', '2045807803', 'https://www.tatamotors.com', 'Public Company', 'tata_motors1945@gmail.com', 'Yjg0YzkyOTQyNTFmYzc2M2NlZDZmNmQ2OTY2YTM5Nzc=', '2023-04-25 14:51:46'),
(2, 'InfraTech Solution Pvt.Ltd', 'Surat', '4578214582', 'https://infratechsolution.com', 'IT Services & Consulting', 'hr@infratechsolution12.com', 'ZjVjMzJjYjVlNTRjZjg1M2M5OWYzOTJlMzAwNDJkODI=', '2023-04-25 21:30:00');

-- --------------------------------------------------------

-- 
-- Table structure for table `job_post`
-- 

CREATE TABLE `job_post` (
  `jobpost_id` int(11) NOT NULL auto_increment,
  `com_id` int(11) NOT NULL,
  `jobtitle` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `minimumsalary` varchar(255) NOT NULL,
  `maximumsalary` varchar(255) NOT NULL,
  `experience` varchar(255) NOT NULL,
  `qualification` varchar(255) NOT NULL,
  `createdAt` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`jobpost_id`),
  KEY `com_id` (`com_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `job_post`
-- 

INSERT INTO `job_post` (`jobpost_id`, `com_id`, `jobtitle`, `description`, `minimumsalary`, `maximumsalary`, `experience`, `qualification`, `createdAt`) VALUES 
(1, 2, 'Android Devloper', 'Java,Kotlin\r\n', '12500', '15500', '1 Year', '12th Pass', '2023-04-25 21:32:40');

-- --------------------------------------------------------

-- 
-- Table structure for table `users`
-- 

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL auto_increment,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `address` text,
  `city` varchar(255) default NULL,
  `state` varchar(255) default NULL,
  `contactno` varchar(255) default NULL,
  `qualification` varchar(255) default NULL,
  `stream` varchar(255) default NULL,
  `passingyear` varchar(255) default NULL,
  `dob` varchar(255) default NULL,
  `age` varchar(255) default NULL,
  `designation` varchar(255) default NULL,
  PRIMARY KEY  (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `users`
-- 

INSERT INTO `users` (`user_id`, `fname`, `lname`, `email`, `password`, `address`, `city`, `state`, `contactno`, `qualification`, `stream`, `passingyear`, `dob`, `age`, `designation`) VALUES 
(1, 'hr', 'hr', 'hr@hr.hr', 'ZjVjMzJjYjVlNTRjZjg1M2M5OWYzOTJlMzAwNDJkODI=', '1111', 'hr', 'hr', '1111111111', 'hr', 'hr', '2022', '5520-02-01', '22', 'hr'),
(2, 'Amish', 'Patel', 'amish123@gmail.com', 'ZDExOGQ3NDZhZWY1ZThhYWZmY2NjNDEzMDkyYjE2OWI=', 'Degam,Navanagar,Chikhli', 'Chikhli', 'Gujarat', '1236547900', 'BCA', 'BCA', '2023', '2003-04-05', '21', 'Developer');

-- 
-- Constraints for dumped tables
-- 

-- 
-- Constraints for table `apply_job_post`
-- 
ALTER TABLE `apply_job_post`
  ADD CONSTRAINT `apply_job_post_ibfk_1` FOREIGN KEY (`jobpost_id`) REFERENCES `job_post` (`jobpost_id`),
  ADD CONSTRAINT `apply_job_post_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

-- 
-- Constraints for table `job_post`
-- 
ALTER TABLE `job_post`
  ADD CONSTRAINT `job_post_ibfk_1` FOREIGN KEY (`com_id`) REFERENCES `company` (`com_id`);
