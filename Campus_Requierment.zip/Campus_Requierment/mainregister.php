<?php

include_once('header.php');

?>
<html>
<head>
    
<title>Register</title>

<style>
    *
    {
    
       border-color:black;
       size: 25px;
    }
.ti{
    text-align:center;
    font-size:20px;
    margin-right: 12%;
    color: #fff;
   }   
   #img{
    height: 75%;
    width:35%;

   }
</style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow ">
   <div class="container-fluid">
     <a class="navbar-brand" href="index.php">Mr.Patel's-JOB.com</a>
     <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
       <span class="navbar-toggler-icon"></span>
      </button>
    <div class="container">
      <h3 class="ti" >Register for Candidate and Company</h3>
    </div>
 <a class="btn btn-secondary me-2" href="register.php" >Candidate </a>
 <a class="btn btn-secondary" href="company-register.php">Compny</a>
 <a href="index.php" class="btn btn-outline-warning ms-1">Back</a>

  </div>
</nav>
<br>
<div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-indicators">
      <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
      <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
      <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
    </div>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img id="img" src="img/bg.jpg" width="80vh" class="d-block w-100" alt="...">
        <div class="carousel-caption d-none d-md-block">
       </div>
      </div>
      <div class="carousel-item">
        <img id="img" src="img/company.jpg" width="80vh" class="d-block w-100" alt="...">
        <div class="carousel-caption d-none d-md-block">
        </div>
      </div>
      <div class="carousel-item">
        <img id="img" src="img/logo4.jpg" width="80vh" class="d-block w-100" alt="...">
        <div class="carousel-caption d-none d-md-block">
        </div>
      </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>
<br><br>
<div class="form-group">
    <div class="form-body">
        <div class="form-panel">
            <div class="nav-bar">
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">     
          <ul class="nav navbar-nav navbar-right">
          <?php
          if(isset($_SESSION['user_id']) && empty($_SESSION['companyLogged'])) {
            ?>
            <li style="padding-right: 25px;"><a href="user/dashboard.php" style="font-size: 35px; color: #053a5a; line-height: 42px;">Dashboard</a></li>
            <li style="padding-right: 25px;"><a href="logout.php" style="font-size: 35px; color: #053a5a; line-height: 42px;">Logout</a></li>
            <?php 
            } else if(isset($_SESSION['user_id']) && isset($_SESSION['companyLogged'])){
            ?>
            <li style="padding-right: 25px;"><a href="company/dashboard.php" style="font-size: 35px; color: #053a5a; line-height: 42px;">Dashboard</a></li>
            <li style="padding-right: 25px;"><a href="logout.php" style="font-size: 35px; color: #053a5a; line-height: 42px;">Logout</a></li>
            <?php } else { 
            ?>
            <li style="padding-right: 25px; "><a href="search.php" style="font-size: 35px; text-decoration:none; color: #053a5a; line-height: 42px;">Search for Jobs</a></li>
            <li style="padding-right: 25px; "><a href="mainregister.php" style="font-size: 35px; text-decoration:0; color: #053a5a; line-height: 42px;">Register</a></li>
            <li style="padding-right: -25px; "><a href="mainlogin.php" style="font-size: 35px; text-decoration:0; color: #053a5a; line-height: 42px;">Login</a></li>
          <?php } ?>
          </ul>
        </div>
            </div>
        </div>
    </div>
 </div>
<br>
<br>

 <?php

 include_once('footer.php');

 ?>
 
</body>
</html>

