<?php

 include_once('header.php');

  if(empty($_SESSION['user_id'])) {
    $_SESSION['callFrom'] = "apply-job-post.php?id=".$_GET[id];
    // header("Location: login.php");
    
  }

  

?>

<html>
  <head>
    <title>Job Details</title>
   
    <link rel="stylsheet" href="css/bootstrap.min.js" />
    <link rel="stylsheet" href="css/jquery.js" />
    <link rel="stylsheet" href="css/jquery.js" /> <link
     href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css"
     rel="stylesheet"
     integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65"
     crossorigin="anonymous"
   />
   <script
     src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
     integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3"
     crossorigin="anonymous"
   ></script>
   <script
     src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js"
     integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V"
     crossorigin="anonymous"
   ></script>

 <style>
</style>
  </head>
<body>

  <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow ">
    <div class="container-fluid">
     <a class="navbar-brand" href="../index.php">Mr.Patel's-JOB.com</a>
     <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
       <span class="navbar-toggler-icon"></span>
      </button>
      <div class="container">
        <h3 class="ti" >My Dashbord</h3>
      </div>
      <a class="btn btn-outline-warning me-2" href="index.php">Back</a>
    </div>
  </nav>

  <center><h3 class="h1 container" >Job Details</h3></center><hr/>
  <table class="table container">
  <thead>
    <tr class="table-primary">
      <th scope="col">Com_Id</th>
      <th scope="col">Job Title</th>
      <th scope="col">Description</th>
      <th scope="col">Minimum Salary</th>
      <th scope="col">Maximum Salary</th>
      <th scope="col">Experience</th>
      <th scope="col">Qualification</th>
      <th scope="col">action</th>
    </tr>
  </thead>
  <tbody>
  <?php 
      $sql = "SELECT * FROM job_post ";
      $result =mysql_query($sql);
        if(mysql_num_rows($result) > 0) {
          while($row =mysql_fetch_assoc($result)) {
        ?>
     <tr>
              
               <td><?php echo $row['com_id']; ?></td>
               
               <td><?php echo $row['jobtitle']; ?></td>
           
               <td><?php echo $row['description']; ?></td>
           
               <td><?php echo $row['minimumsalary']; ?></td>
            
              <td><?php echo $row['maximumsalary']; ?></td>
           
               <td><?php echo $row['experience']; ?></td>
            
               <td><?php echo $row['qualification']; ?></td>

              <td> <a id="btn" href="login.php?id=<?php echo $row['jobpost_id']; ?>" >Apply</a> </td>
               
            </tr>
            <?php 
        }
      }
    ?>
  </tbody>
</table>
         
          
  
<?php

include_once('footer.php');
?>
 
<script src="css/jquery.js"></script>

<script src="css/bootstrap.min.js" ></script>
  

  </body>
  
</html>