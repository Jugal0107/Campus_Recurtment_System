<?php 
session_start();

$con=mysql_connect("localhost","root","");
mysql_select_db("cam_pus");

if(isset($_POST)) {

	$email =  $_POST['email'];
	$password = $_POST['password'];

	$password = base64_encode(strrev(md5($password)));

	$sql = "SELECT user_id, fname, lname, email FROM users WHERE email='$email' AND password='$password'";
	$result =mysql_query($sql);

	if(mysql_num_rows($result) > 0) {
		
		while($row = mysql_fetch_assoc($result)) {
			$_SESSION['name'] = $row['fname'] . " " . $row['lname'];
			$_SESSION['email'] = $row['email'];
			$_SESSION['user_id'] = $row['user_id'];

			if(isset($_SESSION['callFrom'])) {
				$location = $_SESSION['callFrom'];
				unset($_SESSION['callFrom']);
				header("Location: " . $location);
				
			}

			else {

				echo "<script>
				 alert('Candidate-Login Successfully.');
				  window.location='User/dashboard.php';
				</script>";

				// header("Location: index.php");
				
			}

		}
	} else {
		$_SESSION['loginError'] = true;

		echo "<script>
				 alert('Somthing! Want Wrong!.');
				  window.location='login.php';
				</script>";

		// header("Location: login.php");
		
	}

	

} else {

	header("Location: login.php");
	
}
?>