<?php

include_once('header.php');

?>
<html>

<head>
<html>
<head>
 <title>Login</title>

<style>
    *
    {
    
       border-color:black;
       size: 25px;
    }
.al1{
     font-size: 30px;
     color:green;
     text-decoration:none;     
    }
    .d1{
     font-size: 30px;
     color:green;
     text-decoration:none;
    }
    .d2{
     font-size: 30px;
     color:green;
     text-decoration:none;
    }
.ti{
    text-align:center;
    font-size:20px;
    margin-right: 12%;
    color: #fff;
   }
.reg{
     text-align:center;
     font-size:30px;
     background-color:lightgray;
     border:red;
     position:relative;
     background-origin: padding-box;
     line-height:100px;
     width: 50%; 
     height: 120px;
     border-radius: 5px;
     color:black;
    }    
</style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow ">
    <div class="container-fluid">
     <a class="navbar-brand" href="index.php">Mr.Patel's-JOB.com</a>
     <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
       <span class="navbar-toggler-icon"></span>
      </button>
    <div class="container">
      <h3 class="ti" >Login Activity </h3>
    </div>
    <a href="index.php" class="btn btn-outline-warning ms-1">Back</a>
  </div>
</nav>

 <div class="form-group">
    <div class="form-body">
        <div class="form-panel">
            <div class="nav-bar">
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">     
          <ul class="nav navbar-nav navbar-right">
          <?php
          if(isset($_SESSION['user_id']) && empty($_SESSION['companyLogged'])) {
            ?>
            <li style="padding-right: 25px;"><a href="user/dashboard.php" style="font-size: 35px; color: #053a5a; line-height: 42px;">Dashboard</a></li>
            <li style="padding-right: 25px;"><a href="logout.php" style="font-size: 35px; color: #053a5a; line-height: 42px;">Logout</a></li>
            <?php 
            } else if(isset($_SESSION['user_id']) && isset($_SESSION['companyLogged'])){
            ?>
            <li style="padding-right: 25px;"><a href="company/dashboard.php" style="font-size: 35px; color: #053a5a; line-height: 42px;">Dashboard</a></li>
            <li style="padding-right: 25px;"><a href="logout.php" style="font-size: 35px; color: #053a5a; line-height: 42px;">Logout</a></li>
            <?php } else { 
            ?>
            <li style="padding-right: 25px;"><a href="search.php" style="font-size: 35px; color: #053a5a;text-decoration:none; line-height: 42px;">Search for Jobs</a></li>
            <li style="padding-right: 25px;"><a href="mainregister.php" style="font-size: 35px; color: #053a5a; text-decoration:none; line-height: 42px;">Register</a></li>
            <li style="padding-right: -25px;"><a href="mainlogin.php" style="font-size: 35px; color: #053a5a; text-decoration:none; line-height: 42px;">Login</a></li>
          <?php } ?>
          </ul>
        </div>
            </div>
        </div>
    </div>
 </div>

 <br>
 
 <div class="from-group">
    <div class="from-panel">
       <h3 class="ti">Login</h3>
    </div>
 </div>

 <div class="container">
    <div class="form-group">
        <div class="form-body">
            <div class="user" align="center">
              <h2 class="reg" ><a href="login.php" class="d1" >Candidate Login</a></h2>
            </div>
        </div>
    </div>
 </div>

 <br>

 <div class="container">
    <div class="form-group">
        <div class="form-body">
            <div class="user" align="center">
              <h2 class="reg" ><a href="company-login.php" class="d2" >Company Login</a></h2>
            </div>
        </div>
    </div>
 </div>

<br>

 <div class="container">
    <div class="form-group">
        <div class="form-body">
            <div class="admin" align="center">
                <h2 class="reg"><a href="Admin/index.php" class="d2">Admin Login</a></h2>
            </div>
        </div>
    </div>
 </div>
<br>
<br>

<div class="from-group">
    <div class="from-panel">
        <from method="get" action="index.php">
       <h3 class="ti"></h3>
        </from>
    </div>
 </div>


 <br>
 <br>

 <?php

 include_once('footer.php');
 
 ?>
 
</body>
</html>

