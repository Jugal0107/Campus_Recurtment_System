<?php

include_once('header.php');

?>

<html>
<head>
 <title>Campuse Job Requirement</title>

   <style>
    #a-link:hover{
      background-color:lightgray;
      color:blue;
      box-shadow:2px;
      collapse: 2%;
    }
    #bg{
      background-image:url('img/bg.jpg');
      width:100%;
      top:50%;
      left:50%;
      position:auto;
      background-attachment: fixed;


    }
   </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow ">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php">Mr.Patel's-JOB.com</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
      <?php
          if(isset($_SESSION['user_id']) && empty($_SESSION['companyLogged'])) {
            ?>
        <li class="nav-item"><a class="nav-link " aria-current="page" href="user/dashboard.php">Dashboard</a></li>
        <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
        <?php 
            } else if(isset($_SESSION['user_id']) && isset($_SESSION['companyLogged'])){
            ?>
        <li class="nav-item"><a class="nav-link " aria-current="page"href="company/dashboard.php">Dashboard</a></li>
        <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
        <?php } else { 
            ?>
         <li class="nav-item"><a id="a-link" class="nav-link" aria-current="page" href="search.php">Search Job</a></li>
        <li class="nav-item"><a id="a-link" class="nav-link" href="mainregister.php">Register</a></li>
        <li class="nav-item"><a id="a-link" class="nav-link" href="mainlogin.php">Login</a></li>
      
        <?php } ?>
      </ul>
      <form class="d-flex mt-2" action="" method="post">
        <input class="form-control me-2" name="search" type="text"  placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>
<br>

<br>

<?php 

$output = '';

if(isset($_POST['search'])) {
$search = $_POST['search'];

$query = mysql_query("SELECT * FROM job_post WHERE jobtitle LIKE '%$search%'") or die ("Could not search");
$count = mysql_num_rows($query);

if($count == 0){
?>
<p style="font-size: 22px; color: #053a5a;">No Results Found!</p> 
<?php
}else{

?>

<div class="container">
  <div class="row">
    <table class="table" style="width: 100%;">
      <tr>
        <td scope="col" >Job Title</td>
        <td scope="col" >Job Description</td>
        <td scope="col" >Minimum Salary</td>
        <td scope="col" >Maximum Salary</td>
      </tr>
    </table>
  </div>
</div>

</div>

<?php

while ($row = mysql_fetch_array($query)) {
?>

<div class="container ">
<div class="row  mb-3">
  <table style="width: 100%;" border="1" class="table-striped">

    <tr>
      <td style="width: 25%; font-size: 20px; padding-top: 7px; padding-bottom: 7px; padding-left: 20px; color: black;"><a href="apply-job-post.php?id=<?php echo $row['jobpost_id']; ?>"><?php echo $row['jobtitle']; ?></a></td>
      <td style="width: 25%; font-size: 20px; padding-top: 7px; padding-bottom: 7px; padding-left: 20px; color: black;"><?php echo $row['description']; ?></td>
      <td style="width: 25%; font-size: 20px; padding-top: 7px; padding-bottom: 7px; padding-left: 20px; color: black;">Rs.<?php echo $row['minimumsalary']; ?> per Month</td>
      <td style="width: 25%; font-size: 20px; padding-top: 7px; padding-bottom: 7px; padding-left: 20px; color: black;">Rs.<?php echo $row['maximumsalary']; ?> per Month</td>
  
    </tr>
  
  </table>
</div>
</div>

    <?php 
  }
}
}
?>

<br>
</div>
</div>

<section>

<div class="container shadow rounded" id="bg" >
  <div class="row" >
    
    <h2 class="text-center" style="color: yellow; font-size: 35px;"><b>Latest Job Posts</b></h2>

    <br>

    <?php 

    $sql = "SELECT * FROM job_post ORDER BY jobpost_id DESC limit 5";
    $result = mysql_query($sql);
    if(mysql_num_rows($result) > 0) {
    while($row = mysql_fetch_assoc($result)) 
    {
    $sql1 = "SELECT * FROM company WHERE com_id='$row[com_id]'";
    $result1 = mysql_query($sql1);
    if(mysql_num_rows($result1) > 0) {
    while($row1 = mysql_fetch_assoc($result1)) 
    {

    ?>

    <div align="left" >

    <h4 style="font-size: 28px;color:violet;"><i><?php echo $row['jobtitle']; ?></i> <span style="color:green">|</span> <span class="pull-right" style="font-size: 20px; color:white;">Rs. <strong><?php echo $row['minimumsalary']; ?> per Month</span></strong></h4>

    <div style="font-size: 19px;color:green;">
    <div style="color:pink"><strong style="color:skyblue">Company Name : </strong><?php echo $row1['com_name']; ?><span style='color:red;'> | </span><strong style="color:skyblue;">Head Office : </strong><?php echo $row1['headofficecity']; ?><span style="color:red;"> |</span> <strong style="color:skyblue;">Experience Required : </strong><?php echo $row['experience']; ?> </div>
    </div>

    <hr style="border-color:black;">

    </div>

    <?php
    }
    }
    }
    }
    ?>

  </div>
</div>
</section>

<br>
<br>
<br>
<br>


<?php

include_once('footer.php');

?>

</body>
</html>