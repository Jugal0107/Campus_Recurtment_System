<?php
session_start();
$con=mysql_connect("localhost","root","");
mysql_select_db("cam_pus");

$admin=$_POST['admin'];
$password=$_POST['password'];

if(isset($_POST['login']))
{
  $q="select admin password from admin where admin='".$admin."' and password='".$password."' ";

  $r=mysql_query($q);
  $n=mysql_num_rows($r);
  

  if($n==1)
  {
    echo "
    <script>
     alert('Welcome! Admin!');
     window.location='dashboard.php';
    </script>
    ";
  }
  else
  {
    echo "
    <script>
     alert('Something ! Went Wrong!....');
     window.location='index.php';
    </script>
    ";
  }

}
else
{
    header("Admin/index.php");
}

?>