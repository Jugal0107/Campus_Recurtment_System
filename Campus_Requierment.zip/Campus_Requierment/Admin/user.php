<?php

include_once('../header.php');

if(empty($_SESSION['admin_id'])) {
	// header("Location: index.php");
	
}


?>

<html>
  <head>
    
    <title>Users List</title>
  
 <style>
    *
    {
       border-color:black;
       size: 25px;
    }
.al1{
     font-size: 30px;
     color:purple;
     text-decoration:none;     
    }
.ti{
    text-align:center;
    font-size:20px;
    margin-right: 12%;
    color: #fff;
   }     
   .tx{
    font-size:25px;
    padding:5px;
    border-radius:7px ;
    border:2px solid #052d2d;
    width:50%;
   }
   #btn{
    width:10%;
    padding:7px;
    border:none;
    font-size:35px;
    border-radius:5px;
    color:black;
    font-weight:bold;
    background-color:skyblue;
    cursor:pointer;
    outline:none;
   }
   #btn:active{
    width:10%;
    padding:7px;
    border:none;
    font-size:35px;
    border-radius:5px;
    color:green;
    font-weight:bold;
    background-color:pink;
    cursor:pointer;
    outline:none;
   }
   </style>
  </head>
  <body>
    
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow ">
    <div class="container-fluid">
     <a class="navbar-brand" href="index.php">Mr.Patel's-JOB.com</a>
     <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
       <span class="navbar-toggler-icon"></span>
      </button>
      <div class="container">
        <h3 class="ti" >Admin Dashbord</h3>
      </div>
    </div>
    <div class="tx" >
        <a class="btn btn-outline-danger" href="dashboard.php" style="text-decoration:none; color:white;">Dashboard</a>
        <a class="btn btn-outline-danger" href="user.php" style="text-decoration:none; color:white;">Users</a>
        <a class="btn btn-outline-danger" href="company.php" style="text-decoration:none; color:white;">Company</a>
        <a class="btn btn-outline-danger" href="job-posts.php" style="text-decoration:none; color:white;">Job Posts</a>
      </div>
      <a href="../logout.php"  class="btn btn-danger me-2">Logout</a>
  </nav>

  <h3><center>User Details</center></h3>


<div class="form-group me-2 ms-2">  
  <div class="col-md-12" align="center" style="font-size: 22px;" id="print">
        <?php
          $sql = "SELECT * FROM users";
          $result = mysql_query($sql);
          if(mysql_num_rows($result) > 0) {
            echo '<h3 style="color:firebrick;">Total Number of Users: ' . mysql_num_rows($result)  . '</h3>'; 
          }
        ?>
        <br>
          <table class="table table-bordered table-hover mb-0">
            <thead class="bg-dark text-white">
              <th >Sr.No</th>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Email</th>
              <th>Address</th>
              <th>Action</th>
            </thead>
            <tbody>
              <?php
                $sql = "SELECT * FROM users";
                $result = mysql_query($sql);
                if(mysql_num_rows($result) > 0) {
                  $i = 0;
                  while($row = mysql_fetch_assoc($result)) {
                    ?>
                      <tr>
                        <td ><?php echo ++$i; ?></td>
                        <td ><?php echo $row['fname']; ?></td>
                        <td ><?php echo $row['lname']; ?></td>
                        <td ><?php echo $row['email']; ?></td>
                        <td ><?php echo $row['address']; ?></td>
                        <td ><a class="btn btn-danger" href="delete-user.php?id=<?php echo $row['user_id']; ?>" onclick="return msg()" >Delete</a></td>
                      </tr>
                    <?php
                  }
                }
              ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<br>

<div align="center">
  <button class="btn btn-primary" onclick="printDiv('print')" >Print</button>
</div>

  <br>
  <br>
  <br>
  <br>
  
  <?php
 
 include_once('../footer.php');
 
 ?>

<script src="css/jquery.js"></script>
<script src="css/bootstrap.min.js" ></script>

<script>
function msg()
{
  return  confirm("Are You Sure You Have Delete This Row...??");
  
}
</script>

<script type="text/javascript">
function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
}
</script>

  </body>
</html>