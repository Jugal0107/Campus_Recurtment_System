<?php
session_start();
if(empty($_SESSION['admin_id'])) {
	// header("Location: index.php");
	
}

$con=mysql_connect("localhost","root","");
mysql_select_db("cam_pus");

if(isset($_GET)) {
	$sql = "DELETE FROM apply_job_post WHERE jobpost_id='$_GET[id]'";
	if(mysql_query($sql)) {
		$sql1 = "DELETE FROM job_post WHERE jobpost_id='$_GET[id]'";
		if(mysql_query($sql1)) {
		}
		header("Location: job-posts.php");
		
	} else {
		echo "Error";
	}
}
?>