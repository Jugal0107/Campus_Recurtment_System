<?php

include_once('../header.php');

if(empty($_SESSION['admin_id'])) {
  // header("Location: index.php");
  
}

?>

<html>
  <head>
    
   <title>Dashboard</title>

 <style>
    *
    {
       border-color:black;
       size: 25px;
    }
   .al1{
     font-size: 30px;
     color:purple;
     text-decoration:none;     
    }
   .ti{
    text-align:center;
    font-size:20px;
    margin-right: 12%;
    color: #fff;
   }     
   .tx{
    font-size:25px;
    padding:5px;
    border-radius:7px ;
    border:2px solid #052d2d;
    width:50%;
   }
   #btn{
    width:10%;
    padding:7px;
    border:none;
    font-size:35px;
    border-radius:5px;
    color:black;
    font-weight:bold;
    background-color:skyblue;
    cursor:pointer;
    outline:none;
   }
   #btn:active{
    width:10%;
    padding:7px;
    border:none;
    font-size:35px;
    border-radius:5px;
    color:green;
    font-weight:bold;
    background-color:pink;
    cursor:pointer;
    outline:none;
   }
   </style>
  </head>
  <body>

   <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow ">
    <div class="container-fluid">
     <a class="navbar-brand" href="index.php">Mr.Patel's-JOB.com</a>
     <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
       <span class="navbar-toggler-icon"></span>
      </button>
    <div class="container">
      <h3 class="ti" >Admin Dashbord</h3>
    </div>
  </div>
  <div class="tx" >
    <a class="btn btn-outline-danger" href="dashboard.php" style="color:white;">Dashboard</a>
    <a class="btn btn-outline-danger" href="user.php" style="color:white;">Users</a>
    <a class="btn btn-outline-danger" href="company.php" style="color:white;">Company</a>
    <a class="btn btn-outline-danger" href="job-posts.php" style="color:white;">Job Posts</a>
  </div>
  <a href="../logout.php"  class="btn btn-danger me-2">Logout</a>
</nav>
 
 <div class="from-group">
   <div class="from-panel">
       <h3 class="ti">Admin Panel</h3>
   </div>
</div>
<br>

<div class="form-group">
  <div class="form-group">
    <div class="form-body">
        <div class="form-panel" align="center">
           <h3 style="font-size:35px; color:firebrick; background-color:#25d25d;" ><marquee>Welcome To Dashboard, Admin!</marquee></h3>   
        </div>
    </div>
  </div>      
  
  <br>
  <br>
  <br>
  <br>

  <?php
 
 include_once('../footer.php');
 
 ?>

<script src="css/jquery.js"></script>
<script src="css/bootstrap.min.js" ></script>

  </body>
</html>