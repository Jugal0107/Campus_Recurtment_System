<?php
session_start();

$con=mysql_connect("localhost","root","");
mysql_select_db("cam_pus");

if(isset($_POST)) {

    $admin =  $_POST['name'];
	$newpassword =  $_POST['newpassword'];
	
	
	$sql = "SELECT name FROM admin WHERE name='$admin'";
	$result = mysql_query($sql);
	if(mysql_num_rows($result) > 0) {
		$newPass = $newpassword;
		
		// $password = base64_encode(strrev(md5($newPass)));
		
		$sql = "UPDATE admin SET password='$newPass' WHERE name='$admin'";
		if(mysql_query($sql)===TRUE) {

			$_SESSION['passwordChanged'] = $newPass;
			
			echo "
                   <script>
                   alert('Password Reset Successfully..');
                   window.location='index.php';
                   </script>
                  ";

			// header("Location: index.php");
			
		} else {
			echo "Error " . $sql . "<br>" . $conn->error;
		}
	} else {
		
		$_SESSION['emailNotFoundError'] = true;

		echo "
              <script>
              alert('Something ! Went Wrong!....');
              window.location='forgot-password.php';
              </script>
             ";
		// header("Location: forgot-password.php");
	
	}
	
} else {
	header("Location: forgot-password.php");
	
}
?>