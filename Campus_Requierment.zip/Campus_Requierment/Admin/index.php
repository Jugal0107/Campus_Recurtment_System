<?php 
  
  include_once('../header.php');
  
  if(isset($_SESSION['admin_id'])) {
    // header("Location: dashboard.php");
    
}
?>

<html>
  <head>
  
   <title>Admin Login</title>

 <style>
    *
    {
       border-color:black;
       size: 25px;
    }
.al1{
     font-size: 30px;
     color:purple;
     text-decoration:none;     
    }
.ti{
  text-align:center;
    font-size:20px;
    margin-right: 12%;
    color: #fff;
   }     
   .tx{
    font-size:25px;
    padding:5px;
    border-radius:7px ;
    border:2px solid #052d2d;
    width:50%;
    background-color:#4a4a4a;
   }
   .tx:hover{
    font-size:25px;
    padding:5px;
    border-radius:7px ;
    border:2px solid #052d2d;
    width:50%;
    background-color:;
   }
   .a:hover{
    font-size:35px;
    padding:5px;
    border-radius:7px ;
    border:2px solid #052d2d;
    width:50%;
    background-color:green;
   }
   #main-holder{
    width: 35%;
    height:65%;
    display:grid;
    justify-items:center;
    align-items:center;
    background-color:white;
    border-radius:7px;
    box-shadow:0px 0px 5.2px 2.5px lime;
   }
   #login-form{
    align-self:flex-start;
    display:grid;
    justify-items:center;
    align-items:center;
   }
   .login-form-field::placeholder{
    color:#3a3a3a;
   }
   label{
    font-size:25px;
   }
   input{
    font-size:20px;
    position: relative;
   }
   .login-form-field{
    border:none;
    border-bottom:1px solid #3a3a3a;
    margin-bottom:10px;
    border-radius:3px;
    outline:none;
    padding:0px 0px 5px 5px;
   }
   #login-form-submit{
    width:100%;
    padding:7px;
    border:none;
    border-radius:5px;
    color:white;
    font-weight:bold;
    background-color:#3a3a3a;
    cursor:pointer;
    outline:none;
   }
   .a1{
    color:brown;
    text-decoration:0;
    font-size:20px;
   }
   .p1{
    font-size:25px;
    font-family:arial,italic;
    font-weight:bold;
   }
   </style>
  </head>
  <body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow ">
    <div class="container-fluid">
     <a class="navbar-brand" href="index.php">Mr.Patel's-JOB.com</a>
     <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
       <span class="navbar-toggler-icon"></span>
      </button>
    <div class="container">
      <h3 class="ti" >Admin Login</h3>
    </div>
    <a href="../mainlogin.php" class="btn btn-outline-warning ms-1">Back</a>
  </div>
</nav>

<div class="container rounded mt-4 w-50" align="center">
  <form id="login-form" class="shadow rounded row g-3 mt-4" method="post" action="checklogin.php">

    <div class="row mt-4">
      <div class="col-6 container pt-2">
        <input type="text"  class="form-control pt-2 pb-2 shadow" name="admin" placeholder="Username" required=""  />
      </div>
    </div>

    <div class="row mt-4">
      <div class="col-6 container pt-2">
        <input type="password"  class="form-control pt-2 pb-2 shadow" name="password" id="pass-field" placeholder="password" required />
      </div>
    </div>

   <input type="submit" name="login" value="Login" class="mt-5 w-25 btn btn-outline-primary" />
     <a class="a1" href="forgot-password.php" ><h5>Forgot Password?</h5></a>
     
     <br>
   <?php
     if(isset($_SESSION['loginError'])){                
    ?>
    <div>
     <p style="text-align: center; color: red; font-size: 28px;">Invalid Username or Password</p>
    </div>
    <?php
      unset($_SESSION['loginError']);}
    ?>
  </form>
</div>

    <br><br>

<?php

include_once('../footer.php');

?>

<script src="css/jquery.js"></script>
<script src="css/bootstrap.min.js" ></script>

    <script type="text/javascript">
      $(function(){
        $("#successMessage:visible").fadeOut(5000);
      });
    </script>

  </body>
</html>