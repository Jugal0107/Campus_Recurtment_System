<?php

include_once('header.php');

  if(isset($_SESSION['user_id']) && empty($_SESSION['companyLogged'])) {
    // header("Location: user/dashboard.php");
    
  } else if(isset($_SESSION['user_id']) && isset($_SESSION['companyLogged'])) {
  // header("Location: company/dashboard.php");
  
  }
?>

<html>
  <head>
    <title>New User SignUp</title>
   <link href="css/jquery.js" type="javascript/text" alt="validation"/>
   <script src="css/fv.js"></script>
 <style>
    *
    {
       border-color:black;
       size: 25px;
    }
.al1{
     font-size: 30px;
     color:purple;
     text-decoration:none;     
    }
.ti{
  text-align:center;
    font-size:20px;
    margin-right: 12%;
    color: #fff;
   }     
   #main-holder{
    width: 50%;
    height:285%;
    display:grid;
    justify-items:center;
    align-items:center;
    background-color:white;
    border-radius:7px;
    box-shadow:0px 0px 5.2px 2.5px lime;
   }
   #login-form{
    align-self:flex-start;
    display:grid;
    justify-items:center;
    align-items:center;
   }
   .login-form-field::placeholder{
    color:#3a3a3a;
   }
   label{
    font-size:25px;
   }
   input{
    font-size:25px;
    position: relative;
    border:1px solid black;
    border-radius: 5px;
    width: 80%;
    height: 45px;
    padding: 15px; 
   }
   .login-form-field{
    border:none;
    border-bottom:1px solid #3a3a3a;
    margin-bottom:10px;
    border-radius:3px;
    outline:none;
    padding:0px 0px 5px 5px;
   }
   #login-form-submit{
    width:50%;
    padding:7px;
    border:none;
    border-radius:5px;
    color:white;
    font-weight:bold;
    background-color:#3a3a3a;
    cursor:pointer;
    outline:none;
   }
   .p1{
    font-size:25px;
    font-family:arial,italic;
    font-weight:bold;
   }
   .a1{
    color:brown;
    text-decoration:0;
    font-size:20px;
   }
</style>

<script>
  function validate() {
  var fname = document.forms["myform"]["fname"].value;
  if(fname==""){
  alert("Please enter the First name");
  return false;
  }else{
    var f=/^[A-Za-z\s]+$/;
    var fn=f.test(fname);
    if(fn){
    }else{
      alert("Please Enter Valid Format First Name");
      return false;
    }
  }
  var lname = document.forms["myform"]["lname"].value;
  if(lname==""){
  alert("Please enter the Last name");
  return false;
  }else{
    var l=/^[A-Za-z\s]+$/;
    var ln=l.test(lname);
    if(ln){
    }else{
      alert("Please Enter Valid Format Last Name");
      return false;
    }
  }
  var email = document.forms["myform"]["email"].value;
  if(email==""){
  alert("Please enter the email");
  return false;
  }else{
  var re = /^(?:[a-z0-9!#$%&amp;'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&amp;'*+/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])$/;
  var x=re.test(email);
  if(x){
  }else{
  alert("Email id not in correct format");
  return false;
  } 
  } 
  var age = document.forms["myform"]["age"].value;
  if(age==""){
  alert("Please enter the Age");
  return false;
  }
  else{
    var a=/^[1-9]?[0-9]{1}$|^100$/;
    var ag=a.test(age);
    if(ag){
    }else{
      alert("Please Enter Valid Format for Age");
      return false;
    }
  }
  var stream= document.forms["myform"]["stream"].value;
  if(stream==""){
  alert("Please enter the Stream Name");
  return false;
  }else{
  var l=/^[A-Za-z\s]+$/;
  var ln=l.test(stream);
  if(ln){
  }else{
    alert("Please Enter Valid Format Stream Name");
    return false;
  }
  }
  var password = document.forms["myform"]["password"].value;
  if(password==""){
  alert("Please enter the Password");
  return false;
  }else{
    var l=/^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,10}$/;
    var ln=l.test(password);
    if(ln){
    }else{
      alert("Invalid Format Password");
      return false;
    }
  }
  var mobile = document.forms["myform"]["contactno"].value;
  if(mobile==""){
  alert("Please enter the Phone Number");
  return false;
  }else{
    var m=/^\d{10}$/;
    var mb=m.test(mobile);
  if(mb){
  }
  else{
  alert("Phone number is Invalid");
  return false;
  }
  } 
  var state = document.forms["myform"]["state"].value;
  if(state==""){
  alert("Please enter the State Name");
  return false;
  }else{
    var l=/^[A-Za-z\s]+$/;
    var ln=l.test(state);
    if(ln){
    }else{
      alert("Please Enter Valid Format State Name");
      return false;
    }
  }
  var designation = document.forms["myform"]["designation"].value;
  if(designation==""){
  alert("Please enter the Designation");
  return false;
  }else{
    var l=/^[A-Za-z\s]+$/;
    var ln=l.test(designation);
    if(ln){
    }else{
      alert("Please Enter Valid Format Designation");
      return false;
    }
  }
  var city = document.forms["myform"]["city"].value;
  if(city==""){
  alert("Please enter the City");
  return false;
  }else{
    var l=/^[A-Za-z\s]+$/;
    var ln=l.test(city);
    if(ln){
    }else{
      alert("Please Enter Valid Format City Name");
      return false;
    }
  }
  var address = document.forms["myform"]["address"].value;
  if(address==""){
  alert("Please enter the address");
  return false;
  }
}
</script>

</head>
<body>

<nav id="sticky" class="navbar navbar-expand-lg navbar-dark bg-dark shadow ">
  <div class="container-fluid">
     <a class="navbar-brand" href="index.php">Mr.Patel's-JOB.com</a>
     <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
       <span class="navbar-toggler-icon"></span>
      </button>
    <div class="container">
      <h3 class="ti" >SignUp for New User </h3>
    </div>
    <a href="mainregister.php" class="btn btn-outline-warning ms-1">Back</a>
  </div>
</nav>

  <div class="form-group">
    <div class="form-body">
        <div class="form-panel">
            <div class="nav-bar">
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">     
          <ul class="nav navbar-nav navbar-right">
          <?php
          if(isset($_SESSION['user_id']) && empty($_SESSION['companyLogged'])) {
            ?>
            <li style="padding-right: 25px;"><a href="user/dashboard.php" style="font-size: 35px; color: #053a5a; line-height: 42px;">Dashboard</a></li>
            <li style="padding-right: 25px;"><a href="logout.php" style="font-size: 35px; color: #053a5a; line-height: 42px;">Logout</a></li>
            <?php 
            } else if(isset($_SESSION['user_id']) && isset($_SESSION['companyLogged'])){
            ?>
            <li style="padding-right: 25px;"><a href="company/dashboard.php" style="font-size: 35px; color: #053a5a; line-height: 42px;">Dashboard</a></li>
            <li style="padding-right: 25px;"><a href="logout.php" style="font-size: 35px; color: #053a5a; line-height: 42px;">Logout</a></li>
            <?php } else { 
            ?>
            <li style="padding-right: 25px;"><a href="search.php" style="font-size: 35px; color: #053a5a;text-decoration:none; line-height: 42px;">Search for Jobs</a></li>
            <li style="padding-right: 25px;"><a href="mainregister.php" style="font-size: 35px; color: #053a5a; text-decoration:none; line-height: 42px;">Register</a></li>
            <li style="padding-right: -25px;"><a href="mainlogin.php" style="font-size: 35px; color: #053a5a; text-decoration:none; line-height: 42px;">Login</a></li>
          <?php } ?>
          </ul>
        </div>
            </div>
        </div>
    </div>
 </div>

 <div class="container rounded shadow" align="center">
<form id="login-form" class="row g-3 mt-4 " name="myform" onsubmit="return validate()"  method="post" action="adduser.php" enctype="multipart/form-data">
<?php             
  if(isset($_SESSION['registerError'])) {
  ?>
    <div class="form-group">
    <label style="text-align: center; color: red; font-size: 28px;">Email Already Exists! Choose A Different Email!</label>
    </div>
  <?php
  unset($_SESSION['registerError']); }
  ?>

  <div class="row mt-4">
    <div class="col">
      <input type="text" class="form-control shadow " name="fname" id="fname" placeholder="Candidate Name" name="fname" >
      <p class="e-m" style="color:#ff0001" ></p>
    </div>
    <div class="col">
      <input type="text" class="form-control shadow" name="lname" id="lname" placeholder="Last Name" >
      <p class="e-m" style="color:#ff0001" ></p>
    </div>
  </div>

  <div class="row mt-4">
    <div class="col">
      <input type="text" class="form-control shadow" name="email" id="emal" placeholder="email112@address.com"  >
      <p class="e-m" style="color:#ff0001" ></p>
    </div>
    <div class="col">
      <input type="date" class="form-control shadow" name="dob" id="dob" placeholder="DD-MM-YYYY" >
    </div>
  </div>

  <div class="row mt-4">
    <div class="col">
      <input type="text" class="form-control shadow" min="0" maxlength="2"  name="age" id="age" Placeholder="Age"  >
      <p class="e-m" style="color:#ff0001" ></p>
    </div>
    <div class="col">
      <input type="Year" class="form-control shadow" min="0" maxlength="4" name="passingyear" id="passingyear" Placeholder="Passing Year" >
    </div>
  </div>

  <div class="row mt-4">
    <div class="col">
      <input type="text" class="form-control shadow" name="qualification" id="qualification" Placeholder="Qualification"  >
    </div>
    <div class="col">
      <input type="text" class="form-control shadow" name="stream" id="stream" Placeholder="Stream" >
    </div>
  </div>

  <div class="row mt-4">
    <div class="col">
      <input type="password" class="form-control shadow" name="password"  id="password" placeholder="********"  />
      <p class="e-m" style="color:#ff0001" ></p>
    </div>
    <div class="col">
      <input type="text" class="form-control shadow" name="contactno" min="0"  maxlength="10"  id="contactno" Placeholder="Contect No" >
      <p class="e-m" style="color:#ff0001" ></p>
    </div>
  </div>
  
  <div class="row mt-4">
    <div class="col">
        <input type="text" class="form-control shadow" name="state" id="state" Placeholder="State" >
    </div>
    <div class="col">
      <input type="text" class="form-control shadow" name="designation" id="designation" Placeholder="Designation"  />
    </div>
  </div>

  <div class="row mt-4">
    <div class="col">
     <input type="text" class="form-control shadow" name="city" id="city" Placeholder="City"  />
    </div>
    <div class="col">
    <textArea rows="2 " class="form-control shadow" cols="30" name="address" id="address" placeholder="Address"  ></textArea>
    </div>
   
  </div>

<div class="col-12 mb-3">
  <button type="submit" class="btn btn-primary shadow">Sign in</button>
</div>
</form>
</div>

<br>
<br>
<br>   

<?php

include_once('footer.php');

?>

<script src="css/jquery.js"></script>

  <script src="css/bootstrap.min.js" ></script>

  <script src="css/fv.js" ></script>
  

  </body>
</html>