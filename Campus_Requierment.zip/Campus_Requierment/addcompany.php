<?php
session_start();

$con=mysql_connect("localhost","root","");
mysql_select_db("cam_pus");

if(isset($_POST)) {

	$companyname =  $_POST['com_name'];
	$headofficecity =  $_POST['headofficecity'];
	$contactno =  $_POST['contactno'];
	$website =  $_POST['website'];
	$companytype =  $_POST['com_type'];
	$email =  $_POST['email'];
	$password =  $_POST['password'];

	
	$password = base64_encode(strrev(md5($password)));

	$sql = "SELECT email FROM company WHERE email='$email'";
	$result =mysql_query($sql);

	if(mysql_num_rows($result) == 0) {

		$sql = "INSERT INTO company(`com_name`,`headofficecity`,`contactno`,`website`,`com_type`,`email`,`password`) VALUES ('$companyname', '$headofficecity', '$contactno', '$website', '$companytype', '$email', '$password')";

		if(mysql_query($sql)===TRUE){
			$_SESSION['registerCompleted'] = true;
			header("Location: company-login.php");
			
		} else {
			echo "Error ".$sql."<br>".$conn->error;
		}
	} else {
		$_SESSION['registerError'] = true;
		header("Location: company-register.php");
		
	}

} else {

	header("Location: company-register.php");


}
?>