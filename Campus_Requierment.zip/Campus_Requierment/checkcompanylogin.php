<?php 
session_start();

$con=mysql_connect("localhost","root","");
mysql_select_db("cam_pus");

if(isset($_POST)) {


	$email = $_POST['email'];
	$password = $_POST['password'];

	
	$password = base64_encode(strrev(md5($password)));

	$sql = "SELECT com_id, com_name, email FROM company WHERE email='$email' AND password='$password'";
	$result = mysql_query($sql);

	if(mysql_num_rows($result) > 0) {
		
		while($row = mysql_fetch_assoc($result)) {
			$_SESSION['name'] = $row['com_name'];
			$_SESSION['email'] = $row['email'];
			$_SESSION['user_id'] = $row['com_id'];
			$_SESSION['companyLogged'] = true;

			echo "
                   <script>
                   alert('CompanyLogin Successfully..');
                   window.location='company/dashboard.php';
                   </script>
                  ";
			// header("Location: company/dashboard.php");
			

		}
	} else {
		$_SESSION['loginError'] = true;
		echo "
              <script>
              alert('Something ! Went Wrong!....');
              window.location='company-login.php';
              </script>
             ";
		// header("Location: company-login.php");
		
	}

	

} else {

	header("Location: company-login.php");
	
}
?>