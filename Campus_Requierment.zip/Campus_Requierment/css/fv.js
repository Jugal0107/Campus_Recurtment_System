const fname=document.getElementById("fname").Val();
const lname=document.getElementById("lname").Val();
const email=document.getElementById("email").Val();
const age=document.getElementById("age").Val();
const password=document.getElementById("password").Val();
const contactno=document.getElementById("contactno").Val();

function fv()
{
    if(fname.Val.length<2||fname.Val.length>20)
    {
        alert("First Name length should be more than 2 & less than 21");
        fname.focus();
        return false;
    }
    if(lname.Val.length<2||lname.Val.length>15)
    {
        alert("Last(SURNAME) Name length should be more than 2 & less than 21");
        fname.focus();
        return false;
    }
    if(email.Val.match(/^\w+([\.-]?w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/))
    {
       alert("Please Enter a valid email!");
       email.focus();
       return false;
    }
    if(age.Val.length<19||age.Val.length>30)
    {
        
        alert("Age should be more than 19 & less than 31");
        fname.focus();
        return false;
    }
    if(!password.Val.match(/^.{5,15}$/))
    {
        alert("Password must be between 5-15 charecters!");
        password.focus();
        return false;
    }
    if(!contactno.Val.match(/^.{5,10}$/))
    {
        alert("Contact No must be between 10 digits & can't be 0!");
        contactno.focus();
        return false;
    }
return true;
}