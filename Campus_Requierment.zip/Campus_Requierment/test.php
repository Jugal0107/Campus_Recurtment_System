<!-- <?php
function sortArray() {
    $inputArray = array(8, 2, 7, 4, 5);
    $outArray = array();
    for($x=1; $x<=100; $x++) {
        if (in_array($x, $inputArray)) {
            array_push($outArray, $x);
        }
    }
    return $outArray;
}


$sortArray = sortArray();
foreach ($sortArray as $value) {
    echo $value . "<br />";
}
?>
 -->

<?php

	$con=mysql_connect("localhost","root","");
    mysql_select_db("cam_pus");

	$sql = "SELECT * FROM job_post";
	$result = mysql_query($sql);

	// $count = mysql_num_rows($sql);

    while ($row = mysql_fetch_array($result)) {
    	echo $row['jobtitle'];
    	echo "<br>";

    	for($x=0;$x<$count;$x++){
    	    for($i = 0; $i < $count-1; $i ++){

        if($row['jobpost_id'] > $row['jobpost_id']+1) {
            $temp = $row['jobpost_id']+1;
            ($row['jobpost_id']+1) == $row['jobpost_id'];
            $row['jobpost_id'] = $temp;
        }       
    }	
    	}
    }

  ?>